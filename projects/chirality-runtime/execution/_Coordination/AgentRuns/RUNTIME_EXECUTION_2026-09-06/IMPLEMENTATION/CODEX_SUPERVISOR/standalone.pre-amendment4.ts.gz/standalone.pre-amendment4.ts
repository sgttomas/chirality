import { lstat, readdir, realpath, unlink } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { RuntimeError, type RuntimeCompatibilityIdentity, type WorkerContinuity } from "@chirality/runtime-contracts";
import {
  assertContinuity, AuthRegistry, DelegatedRuntime, EngineRegistry, HostedConsentStore, privateDirectory,
  privateRead, ProcessSupervisor, ProjectRegistry, publishPrivate, recordKey, ResidencyCoordinator,
  RuntimeService, SessionStore, TurnCoordinator, WorkerRetirementCoordinator
} from "@chirality/runtime-core";
import { RuntimeDaemon } from "./runtime-daemon.js";
import { startSupervisorServer, SupervisorClient, type SupervisorCredential } from "./supervisor-server.js";

export interface StandaloneConfig {
  schema: "chirality-standalone/v1";
  mode: "controlled-worker";
  runtimeDirectory: string;
  daemonSocket: string;
  supervisorSocket: string;
  supervisorCredential: string;
  project: {
    projectId: string;
    identity: WorkerContinuity;
    compatibility: RuntimeCompatibilityIdentity;
    codexHome: string;
    retirementDirectory: string;
  };
  worker: { executablePath: string; args: string[]; maxRunMs?: number };
}
export interface StandaloneJob { role: "daemon" | "supervisor"; socketPath: string; close(): Promise<void> }
interface CredentialRecord {
  schema: "chirality-supervisor-credential/v1";
  socketPath: string;
  bindingDigest: string;
  credential: SupervisorCredential;
}
const invalid = (message: string) => new RuntimeError("INVALID_REQUEST", message);
const unavailable = (message: string) => new RuntimeError("ENGINE_UNAVAILABLE", message, 503);
function keys(value: unknown, allowed: string[]): asserts value is Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some(key => !allowed.includes(key))) throw invalid("Unsupported standalone configuration fields");
}
function absolute(path: string): void {
  if (typeof path !== "string" || !isAbsolute(path) || resolve(path) !== path || /[\x00-\x1f]/.test(path)) throw invalid("Standalone paths must be canonical absolute paths");
}
function within(root: string, path: string): boolean {
  const value = relative(root, path);
  return value !== "" && value !== ".." && !value.startsWith(`..${sep}`) && !isAbsolute(value);
}
function child(root: string, path: string): string {
  if (typeof path !== "string" || !path || isAbsolute(path) || /[\x00-\x1f]/.test(path)) throw invalid("Storage paths must be relative to the runtime directory");
  const result = resolve(root, path);
  if (!within(root, result) || relative(root, result) !== path) throw invalid("Storage paths must be normalized and contained");
  return result;
}
async function privateFile(path: string): Promise<void> {
  absolute(path);
  const info = await lstat(path);
  if (!info.isFile() || info.isSymbolicLink() || info.uid !== process.getuid?.() || (info.mode & 0o777) !== 0o600 || await realpath(path) !== path) throw invalid("Configuration and credentials must be canonical owner-only 0600 regular files");
  await privateDirectory(dirname(path));
}
/** Validate existing storage before older registry components consume it. */
async function privateTree(path: string): Promise<void> {
  await privateDirectory(path);
  for (const name of await readdir(path)) {
    const entry = join(path, name), info = await lstat(entry);
    if (info.isSymbolicLink() || info.uid !== process.getuid?.()) throw invalid("Runtime storage contains an unsafe owner or alias");
    if (info.isDirectory()) await privateTree(entry);
    else if ((!info.isFile() && !info.isSocket()) || (info.mode & 0o777) !== 0o600) throw invalid("Runtime storage must contain only private files and Unix sockets");
  }
}
export async function readStandaloneConfig(path: string): Promise<StandaloneConfig> {
  if (process.platform === "win32") throw unavailable("Standalone runtime requires Unix domain sockets");
  await privateFile(path);
  const config = await privateRead<StandaloneConfig>(path);
  keys(config, ["schema", "mode", "runtimeDirectory", "daemonSocket", "supervisorSocket", "supervisorCredential", "project", "worker"]);
  if (config.schema !== "chirality-standalone/v1" || config.mode !== "controlled-worker") throw unavailable("Only explicit controlled-worker standalone mode is available; hosted production mode is unsupported");
  absolute(config.runtimeDirectory);
  if (!within(config.runtimeDirectory, path)) throw invalid("Configuration must reside in its private runtime directory");
  await privateTree(config.runtimeDirectory);
  keys(config.project, ["projectId", "identity", "compatibility", "codexHome", "retirementDirectory"]);
  keys(config.worker, ["executablePath", "args", "maxRunMs"]);
  keys(config.project.identity, ["canonicalRoot", "accountId", "accountEpoch", "policyDigest", "cwd"]);
  keys(config.project.compatibility, ["compatibilityIdentity", "contractBasisSha256"]);
  if (typeof config.project.projectId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(config.project.projectId)) throw invalid("A bounded project ID is required");
  await assertContinuity(config.project.identity);
  if (!/^root-runtime-[1-9][0-9]*$/.test(config.project.compatibility.compatibilityIdentity) || !/^[a-f0-9]{64}$/.test(config.project.compatibility.contractBasisSha256)) throw invalid("A precise compatibility basis is required");
  const paths = [config.daemonSocket, config.supervisorSocket, config.supervisorCredential, config.project.codexHome, config.project.retirementDirectory].map(path => child(config.runtimeDirectory, path));
  if (new Set(paths).size !== paths.length || paths.includes(path)) throw invalid("Standalone resources require distinct storage paths");
  for (const socket of paths.slice(0, 2)) if (Buffer.byteLength(socket!) > 100) throw invalid("Unix socket path is too long");
  absolute(config.worker.executablePath);
  const executable = await lstat(config.worker.executablePath);
  if (!executable.isFile() || executable.isSymbolicLink() || await realpath(config.worker.executablePath) !== config.worker.executablePath || (executable.mode & 0o111) === 0) throw invalid("Controlled worker requires a canonical executable regular file");
  if (!Array.isArray(config.worker.args) || config.worker.args.length > 128 || config.worker.args.some(arg => typeof arg !== "string" || arg.length > 4096 || /[\x00-\x1f]/.test(arg))) throw invalid("Invalid trusted worker argument vector");
  if (config.worker.maxRunMs !== undefined && (!Number.isSafeInteger(config.worker.maxRunMs) || config.worker.maxRunMs < 1 || config.worker.maxRunMs > 300_000)) throw invalid("Invalid worker deadline");
  return structuredClone(config);
}
async function loadCredential(config: StandaloneConfig): Promise<SupervisorCredential> {
  const path = child(config.runtimeDirectory, config.supervisorCredential);
  await privateFile(path);
  const record = await privateRead<CredentialRecord>(path);
  const socketPath = child(config.runtimeDirectory, config.supervisorSocket);
  if (!record || record.schema !== "chirality-supervisor-credential/v1" || record.socketPath !== socketPath || record.bindingDigest !== recordKey(config)) throw unavailable("Supervisor credential does not bind this standalone configuration");
  const credential = record.credential;
  if (!credential || typeof credential.owner !== "string" || !new RegExp(`^${process.getuid?.()}:[1-9][0-9]*$`).test(credential.owner) || typeof credential.epoch !== "string" || !/^[a-f0-9-]{36}$/.test(credential.epoch) || typeof credential.token !== "string" || !/^[a-f0-9]{64}$/.test(credential.token)) throw unavailable("Invalid supervisor generation credential");
  try { process.kill(Number(credential.owner.split(":")[1]), 0); } catch { throw unavailable("Supervisor credential belongs to a dead process"); }
  const socket = await lstat(socketPath);
  if (!socket.isSocket() || socket.uid !== process.getuid?.() || (socket.mode & 0o777) !== 0o600) throw unavailable("Supervisor Unix endpoint is not owner-private");
  return credential;
}
export async function startStandaloneJob(role: "daemon" | "supervisor", configPath: string): Promise<StandaloneJob> {
  if (role !== "daemon" && role !== "supervisor") throw invalid("Expected daemon or supervisor job");
  const config = await readStandaloneConfig(configPath);
  const socketPath = child(config.runtimeDirectory, role === "daemon" ? config.daemonSocket : config.supervisorSocket);
  if (role === "supervisor") {
    const codexHome = child(config.runtimeDirectory, config.project.codexHome);
    await privateDirectory(codexHome);
    const workers = new ProcessSupervisor({ command: config.worker.executablePath, args: config.worker.args, cwd: config.project.identity.canonicalRoot,
      env: { CODEX_HOME: codexHome }, maxRunMs: config.worker.maxRunMs ?? 30_000 });
    const server = await startSupervisorServer({ socketPath, supervisor: workers, recoverStale: true });
    const credentialPath = child(config.runtimeDirectory, config.supervisorCredential);
    const record: CredentialRecord = { schema: "chirality-supervisor-credential/v1", socketPath, bindingDigest: recordKey(config), credential: server.credential };
    try { await publishPrivate(credentialPath, record, false); }
    catch (error) { await server.close(); await workers.close(); throw error; }
    let closing: Promise<void> | undefined;
    return { role, socketPath, close() {
      closing ??= (async () => {
        const stopped = await Promise.allSettled([server.close(), workers.close()]);
        const current = await privateRead<CredentialRecord>(credentialPath);
        if (current?.credential.epoch === record.credential.epoch) await unlink(credentialPath);
        for (const result of stopped) if (result.status === "rejected") throw result.reason;
      })();
      return closing;
    } };
  }
  const credential = await loadCredential(config);
  const supervisor = new SupervisorClient({ socketPath: child(config.runtimeDirectory, config.supervisorSocket), credential });
  await supervisor.inventory(); // Prove the loaded credential belongs to the live endpoint.
  const projects = new ProjectRegistry(config.runtimeDirectory, {});
  const registered = await projects.requireAuthorized(config.project.projectId);
  if (registered.canonicalRoot !== config.project.identity.canonicalRoot) throw invalid("Configured root differs from explicit project registration");
  const sessions = new SessionStore(config.runtimeDirectory, projects), engines = new EngineRegistry();
  const offline = async (): Promise<never> => { throw unavailable("No hosted or local model engine is configured in controlled standalone mode"); };
  const residency = new ResidencyCoordinator({ async listStatus() { return []; }, load: offline, unload: offline }, config.runtimeDirectory);
  const service = new RuntimeService(projects, sessions, engines, residency, new TurnCoordinator(projects, sessions, engines, residency), new AuthRegistry(config.runtimeDirectory), {
    async get() { return undefined; }, async status() { return { configured: false }; }, set: offline, remove: offline
  });
  const retirement = new WorkerRetirementCoordinator({ directory: child(config.runtimeDirectory, config.project.retirementDirectory) });
  await retirement.reconcile();
  const delegated = new DelegatedRuntime({ daemonId: "standalone-starting", projects: new Map([[config.project.projectId, {
    identity: config.project.identity, compatibility: config.project.compatibility, supervisor,
    consent: new HostedConsentStore({ canonicalRoot: config.project.identity.canonicalRoot, codexHome: child(config.runtimeDirectory, config.project.codexHome) }), retirement, evidenceClass: "controlled-worker"
  }]]) });
  const daemon = new RuntimeDaemon({ socketPath, runtimeDirectory: config.runtimeDirectory, service, delegated });
  await daemon.start();
  return { role, socketPath, close: () => daemon.stop() };
}
