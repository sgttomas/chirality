## Piping collection: barrier 

Status: validated; head `da504e5a9a1a386494df80e965abda88b4020312`, target `fd195cf4287e84572a12183169478a6f7ddf6a92`.

Selected 445; omitted 0. Collection is not a test pass.
