> This is the wire companion to revision02 CONTRACT.md, pending independent review and ROOT selection. The parent selected wire bytes remain immutable. EXACT_BOUNDARY.md defines the separate proposed bounded branch; none of its fields may be inferred into the existing branches.

# Prospective revision 02 — Closed wire types for precision-2

This is the exact field-name companion to CONTRACT.md. It adds no outer document version. All records have closed keys; `?` means nullable/conditionally absent only where specified here. Arbitrary extra fields or renamed kinds are not accepted. The method/semantic registry pins these definitions and actual schema hashes before emission. A ContentRef is data, never an instruction to fetch executable code.

## Scalar and reference primitives

```
Sha256 = 64 lowercase hexadecimal characters
Id = nonempty string
Count = nonnegative JSON safe integer, never a boolean
BasisRef = {ref_type:"load_case", ref_id:Id}
InputManifestChecksum = {
  algorithm:"sha256", canonicalization:"rfc8785_jcs",
  payload_ref:{object_type:"InputManifest", ref:Id},
  payload_scope:"input_manifest", value:Sha256
}
BinaryScalar = {negative:boolean, significand:string, exponent2:integer}
ContentRef = {
  artifact_id:Id,
  schema_id:Id,
  canonicalization:"openpipestress_jcs_ijson_v1",
  sha256:Sha256
}
```

`BinaryScalar` represents (-1)^negative×significand×2^exponent2. Integer strings are unsigned canonical decimal (`0` or positive without leading zeros), odd when nonzero; zero has exponent0 and retains its explicit sign. It is not a generic JSON quantity or a physical moment. Precision and admitted exponent/significand bounds belong to its containing record's registered arithmetic/range profile. Validate string lengths and safe integer exponents before allocating BigInts. Nonfinite values never masquerade as a scalar. The public scientific quantity rows remain unchanged finite f64 value/unit objects. An internal binary-digit ValueRecord is converted exactly to this decimal integer spelling; the negative boolean, including negative zero, is not discarded.

All counts, dimensions, precision sizes and ordinals below are Count with the additional stated bounds; JSON booleans never satisfy an integer check. Exponents are signed safe integers further limited by the admitted range profile. InputManifestChecksum is the existing profile spelling at this inspected basis; an actual differently versioned manifest contract must be explicitly supported, not silently relabelled into this shape.

ContentRef's artifact ID is `numerical-artifact:sha256:<sha256>`. Its digest covers the exact canonical payload identified by `schema_id`; that payload includes its own schema identifier but no self checksum. Existing source/raw/package checksums keep their original structures and meanings. This new internal evidence-link type deliberately has one fixed spelling across Rust/Python/TS rather than inheriting different raw/analysis reference shapes. Registry qualification/range entries resolve these links locally; a result cannot register its own new schema or accepted method by naming an artifact.

Known artifact schemas for this first method are `arithmetic_wrapper_qualification_v1`, `publication_adapter_qualification_v1`, `numerical_method_policy_v1`, `numerical_range_profile_v1`, `consumed_solver_request_v1`, `source_energy_state_v1`, `contribution_precision_attempt_v1`, `retained_structural_state_v1`, `contribution_precision_check_v1`, `numerical_execution_v1`, `numerical_factor_report_v1`, `numerical_check_rows_v1`. They are numerical evidence types within precision-2, not additional analysis/result family versions. Unknown schema ID is unsupported. The arithmetic qualification artifact identifies the admitted wrapper/backend/build and tested/proved operation scope; the numerical method policy separately defines structural acceptance and mandatory checks. Range artifacts identify the admitted resource/arithmetic range; a known pending qualification can be reported in an unsuccessful attempt but cannot support selected success. The receipt publication.qualification_ref must target publication_adapter_qualification_v1 and bind the distinct exact-transfer/publication role. The receipt arithmetic.qualification_ref must target arithmetic_wrapper_qualification_v1, range_profile_ref targets numerical_range_profile_v1, and CheckSummary.policy_ref targets the registered numerical_method_policy_v1 for its method. These are structured JSON registry/evidence payloads; original Markdown/source/test files are linked inside them with their truthful original hash conventions rather than falsely hashed as JCS text.

## Source and state

```
SourceBinding = CompleteSourceBinding | IncompleteSourceBinding
CompleteSourceBinding = {
  admission_state:"complete",
  run_id:Id,
  model_ref:Id,
  input_manifest_checksum: InputManifestChecksum,
  basis_ref:BasisRef,
  formulation_profile_id:Id,
  source_request_checksum:ContentRef, // schema consumed_solver_request_v1
  source_energy_checksum:ContentRef,  // schema source_energy_state_v1
  dof_map_checksum:Sha256,
  source_coverage_checksum:Sha256
}
IncompleteSourceBinding = {
  admission_state:"incomplete",
  run_id:Id, model_ref:Id,
  input_manifest_checksum:InputManifestChecksum,
  basis_ref:BasisRef, formulation_profile_id:Id,
  source_request_checksum:ContentRef|null,
  source_energy_checksum:null,
  dof_map_checksum:Sha256|null,
  source_coverage_checksum:Sha256|null,
  unavailable:[{
    field:"source_request_checksum"|"source_energy_checksum"|
          "dof_map_checksum"|"source_coverage_checksum",
    reason:"interrupted_before_materialization"|"unsupported_source_family"|
           "resource_limit_before_materialization"|"source_evaluation_failed"|"not_reached"
  }]
}
```

Incomplete bindings preserve the actual invocation/manifest/model/case identity and each available completed digest. Source_energy_checksum is always null until full source admission; unavailable names exactly all null fields, once each, with actual reasons. A non-null field must identify a genuinely completed corresponding artifact/inventory, never a placeholder or hash of an empty stand-in. Source-energy completion requires admitted family/coverage semantics and all complete binding fields; a fully materialized admitted source therefore uses CompleteSourceBinding even if a later resource/solve step fails. Partial payloads are not hashed as a complete source_energy_state_v1. The core no-manifest draft remains internal; this incomplete wire binding is for an actual available invocation context finalized as an unsuccessful result.

An incomplete receipt cannot have a selected attempt, retained state, assessment, source_energy_retained fidelity, checks_passed/sensitive quality or Current eligibility. Its attempt report uses the same union, reaches source_admission, has no later structural phase execution records and has source_incomplete/precision_contract_unresolved/range_exceeded/resource_limit/interrupted/failed outcome. Numeric case status is unresolved or failed, never not_assessed for an actual attempt. Source-admission diagnostics may preserve actual preflight/arithmetic facts; null later-phase refs do not claim that no source-validation operation occurred. No complete execution/source evidence is invented.

The receipt binding records the latest actually reached admission state. Across attempts the required invocation fields are identical; every earlier non-null digest must match the later binding. Missing fields may become available, but established fields cannot change. Once complete, the source binding is identical for all subsequent attempts. Earlier incomplete reports remain unchanged. Every retained state, realization, execution, factor/check leaf and assessment requires CompleteSourceBinding; only the receipt and early attempt report allow the incomplete variant.

The existing input-manifest checksum object must exactly match the supplied manifest evidence, including algorithm, canonicalization, payload reference/scope and value. No relabelled request/raw/retained-state checksum is accepted in that slot. `source_energy_state_v1` uses CompleteSourceBinding (with its own source-energy checksum omitted) and its payload contains exactly `schema_id`, `source_binding_without_source_energy_checksum`, `dof_map`, `supported_families`, `elements`, `supports`, `loads`, `constraints`, `coverage`. Its numeric inputs use their actual represented source convention, not rounded displays. Element/support family records are the recognized source-energy adapter records; their maps/parameters/ownership are explicitly registered by the method. Unknown family or a rounded-only legacy matrix has no source-energy qualification. The coverage records identify every required source entity/contribution, not just a total count.

`consumed_solver_request_v1` contains `schema_id`, `input_contract_id`, `model`, `materials_override`, `solver_mode`, `solver_settings` and `method_policy_refs`, using the actual consumed typed values and existing source number conventions. It has no output/raw/run-artifact checksum. Core draft and source-owned finalizer compare that exact descriptor/checksum before binding the caller's real manifest. If the actual invocation context cannot establish the correspondence, a valid completed wire receipt is not fabricated. The source binding's raw run ID and outer consumer alias are not interchangeable.

This source checksum binds the fixed recipe/formulation IDs and exact represented inputs, not precision-specific evaluated matrices or normalized vectors. Rebuilding at p and 2p preserves that source identity while changing the realized matrix/loads. Each phase execution therefore records its own `realization_sha256` (null before that phase materializes its equations), covering its actual evaluated/scaled/reduced equations, precision and maps. Do not force unequal p-bit realizations to claim the same realization hash or permit their different source recipes to hide behind the same model ID.

`retained_structural_state_v1` payload contains exactly `schema_id`, `source_binding`, `precision_bits`, `dof_map`, `global_values`, `basic_deformations`, `recovered_actions`. Global values are ordered BinaryScalars; basic/action records carry exact entity/frame/quantity/DOF or component identity, units and ordered BinaryScalars. The initial registry permits only the supported structural family records. `dof_map` must agree byte-for-byte with the source inventory and its checksum; global values include actual prescribed coordinates. Entity identity, units and array dimensions cannot be inferred from position after a case swap.

The RetainedState header in CONTRACT.md uses ContentRefs in `source_energy_checksum` and `content_ref`, plain Sha256 in `dof_map_checksum`, `state_checksum` and `recovered_structural_rows_checksum`. Its state checksum equals content_ref.sha256. Its precision equals the selected attempt's **candidate_bits**, and its checksum equals the cross-precision candidate checksum. The verification state is separately named; a producer cannot silently publish verification-state values while claiming the candidate state was their source.

`recovered_structural_rows_checksum` specifically equals `assessment.publication.projected_raw_rows_sha256`: despite its historical field spelling, it hashes the projected structural raw-row subset, not the high-precision action array. Hash the existing checked canonical JSON projection `{schema_id:"projected_structural_rows_v1", source_binding:<complete binding>, selected_state_sha256:<candidate state hash>, rows:[{source_row_index:Count, row:<complete original raw ResultItem>}...]}` in original raw order for the required structural inventory. No numerical-quality receipt or final raw-envelope hash enters those rows/projection. The retained content's high-precision recovered actions remain covered by state_checksum. Altering either side or confusing these scopes fails binding.

DOF-map checksums hash the exact ordered canonical dof_map payload; source_coverage_checksum hashes the exact canonical coverage payload in the admitted source recipe. CheckSummary inventory digests hash the canonical ordered required/evaluated inventory payloads; evaluated IDs are normalized into required-source order only after duplicate/missing/extra detection. A realization digest covers `{source_energy_sha256, precision_bits, ordered_dof_map, scale_description, reduced_matrix_representation, reduced_rhs, prescribed_values}` using the actual precision-safe scalar representation and exact registered dense/profile payload shape. No stage/report/receipt checksum appears in a realization. Method-specific source-family, matrix and leaf-row schema details must be frozen with their producer/consumer registration; these scope/equality rules are not permission to accept unnamed arbitrary payloads.

## Attempt facts and arithmetic precision

The Attempt fields in CONTRACT.md are fixed. `candidate_bits` names actual target stored/returned arithmetic precision. The proposed hybrid profile uses explicit Astro ToEven and checked raw operands, with only128/256/512/1024 contexts. No Context(0) Dashu arithmetic composition is part of this profile. Zero has an explicit target context only after exact-zero identity and sign checks; nonzero returned width and actual backend precision are checked.

Every actual attempt report includes these fields:

```
{
 schema_id:"contribution_precision_attempt_v1",
 source_binding:SourceBinding,
 ordinal:Count,
 candidate_bits:Count,
 verification_bits:Count|null,
 residual_bits:Count|null,
 arithmetic_profile_id:Id,
 reached_stage:<Attempt.completed_stage>,
 outcome:<Attempt.outcome>,
 failure_ids:[Id],
 executions:{
   candidate:ContentRef|null,
   verification:ContentRef|null,
   retained_residual:ContentRef|null,
   independent_recovery:ContentRef|null
 },
 retained_state_checksum:Sha256|null,
 assessment_checksum:Sha256|null
}
NumericalExecution = {
 schema_id:"numerical_execution_v1",
 source_binding:CompleteSourceBinding,
 attempt_ordinal:Count,
 phase:"candidate"|"verification"|"retained_residual"|"independent_recovery",
 arithmetic_profile_id:Id,
 precision_bits:Count,
 arithmetic_return_count:Count,
 maximum_returned_significand_bits:Count|null,
 precision_violation_ids:[Id],
 realization_sha256:Sha256|null,
 input_state_sha256:Sha256|null,
 output_state_sha256:Sha256|null,
 reached_stage:"assembly"|"factorization"|"solve"|"recovery"|
               "residual_evaluation"|"independent_recovery_evaluation",
 outcome:"completed"|"precision_contract_unresolved"|"range_exceeded"|
         "factor_unresolved"|"resource_limit"|"interrupted"|"failed",
 report_refs:[ContentRef]
}
```

Each non-null executions entry resolves to numerical_execution_v1 with the matching phase/source/attempt/profile; no execution record exists merely because that phase was planned. A started failed phase has its real record/outcome. Candidate and verification records are separately created and hashed, even if some values happen to match. Their reports reference only lower-level factor/check leaves, never their owning attempt/assessment/receipt.

Arithmetic_return_count counts results returned across the qualified target-precision API, not hidden exact intermediates. Zero returns requires maximum=null; positive count requires an observed maximum. Completed phases have no precision violations and maximum≤their own precision_bits when non-null. No operation is invented for a vacuous no-free-DOF phase; its source and no_free_dofs factor/recovery facts must establish that exception. A p+1 returned significand cannot pass as p. The earlier Dashu Context and division counterexamples remain rejected historical evidence, not alternative arithmetic profiles. The new arithmetic profile is astro_raw_binary_to_even_ieee_zero_v1; neither execution records nor local inexact flags establish correctness to the physical source without the separately required source and structural checks.

For a selected successful attempt:

- candidate execution is completed at p∈{128,256,512}, reaches recovery, and identifies the actual p-bit realization and candidate output state. Its input_state_sha256 is null because it solves from the fixed source; refinement history belongs to its method reports.
- verification execution is completed at2p (including1024 for a512 candidate), reaches recovery, and identifies its own realization/output state; input_state_sha256 is null for the independently rebuilt solve. Candidate and verification realizations are separately bound, not forced to be equal.
- retained_residual execution is completed at the actually reported residual_bits≥p+64 within the registered ceiling, reaches residual_evaluation, has the candidate output state as input and no output state, and identifies the intended-source realization used for that residual.
- independent_recovery execution is completed at its recorded precision (at least p and satisfying the registered method policy), reaches independent_recovery_evaluation, has the candidate output state as input and no output state, and identifies the source realization and energy/force/moment check leaves actually used.

Attempt.verification_bits is null exactly when that execution entry is null, otherwise equals its precision_bits; residual_bits follows the same rule for retained_residual. A started-but-failed verification reports its actual precision but cannot support selected success. The selected RetainedState and assessment candidate state must equal candidate execution.output_state_sha256; cross-precision verification state equals verification execution.output_state_sha256. Assessment execution references must equal the selected attempt's corresponding entries. Each factor/check report is among that execution's report_refs and agrees on source/state/realization/precision as applicable. Candidate512/verification1024 is valid; candidate1024 is not in this method's schedule.

Candidate and verification executions each require their own same-precision positive factor leaf (or valid no_free_dofs leaf) for their own realization/ordered map; a verification cannot borrow the candidate's factor evidence. The retained-residual execution includes both exact leaves referenced by its free-equilibrium and prescribed-compatibility summaries. The independent-recovery execution includes the three exact energy/force/moment leaves. Required refs are present once each and satisfy their registered comparisons; a completed outcome with empty/unbound required reports is invalid. Extra diagnostic leaves do not substitute for any required leaf.

Early source-admission failure has all four execution entries null, verification/residual bits null, retained/assessment hashes null, and no fabricated arithmetic maximum. Later failures retain any completed/failed actual phase records but cannot select the attempt. These are metadata/binding checks, not consumer re-execution of the solver.

## Assessment objects

Use these exact fields for the seven sections of ExtendedAssessment:

```
source_coverage = {
  expected_sha256:Sha256, evaluated_sha256:Sha256,
  expected_count:integer, evaluated_count:integer,
  missing_ids:[Id], extra_ids:[Id], supported_family_ids:[Id]
}
factor = {
  kind:"cholesky"|"ldlt_profile"|"no_free_dofs",
  precision_bits:integer, dimension:integer,
  positive_pivots:integer, nonpositive_pivots:integer,
  unresolved_pivots:integer,
  ordered_dof_map_sha256:Sha256, report_ref:ContentRef
}
retained_equilibrium = {
  execution_ref:ContentRef,
  state_sha256:Sha256,
  equation_basis:"source_energy_contributions",
  state_basis:"retained_internal_solution",
  free_equations:CheckSummary,
  prescribed_compatibility:CheckSummary
}
cross_precision = {
  candidate_execution_ref:ContentRef, verification_execution_ref:ContentRef,
  candidate_state_sha256:Sha256, verification_state_sha256:Sha256,
  candidate_bits:integer, verification_bits:integer,
  displacements:CheckSummary, actions_and_reactions:CheckSummary
}
independent_recovery = {
  execution_ref:ContentRef,
  state_sha256:Sha256,
  configuration_basis:"reference_configuration",
  reference_geometry_sha256:Sha256,
  moment_origin:{frame:"model_global", unit:"m", coordinates:[BinaryScalar,BinaryScalar,BinaryScalar]},
  element_energy:CheckSummary,
  force_balance:CheckSummary,
  moment_balance:CheckSummary
}
publication = {
  state_sha256:Sha256,
  profile_id:"astro_exact_binary_to_dashu_binary64_v1",
  required_structural_fields_sha256:Sha256,
  projected_raw_rows_sha256:Sha256,
  structural_fields:CheckSummary,
  unrepresentable_ids:[Id]
}
sensitivity = {
  estimator_id:Id|null, basis:Id,
  estimate:BinaryScalar|null, unavailable_reason:Id|null,
  finding_ids:[Id]
}
```

The selected method's structured assessment artifact is `contribution_precision_check_v1`, with `schema_id`, `source_binding`, `retained_state_sha256` and these seven objects. It cannot include another method's report or a different case's state. A receipt embeds ExtendedAssessment as above or copies it from that bound artifact; if both exist their canonical bodies must agree. Missing mandatory content yields incomplete verification, never implicit success.

For the attempt report's `assessment_checksum`, hash the canonical object `{schema_id:"contribution_precision_check_v1", source_binding:receipt.source_binding, retained_state_sha256:receipt.retained_state.state_checksum, ...receipt.assessment}`. The embedded seven-object body is not independently hashed under a different projection. This fixes the one checksum scope used by both producer and consumers.

Factor.report_ref is a **leaf** `numerical_factor_report_v1`: `schema_id`, `source_binding`, `attempt_ordinal`, `realization_sha256`, `precision_bits`, `kind`, `dimension`, `ordered_dof_map`, `pivot_evidence`, `condition_evidence`, `range_findings`. A CheckSummary.report_ref is a **leaf** `numerical_check_rows_v1`: `schema_id`, `source_binding`, `check_id`, `state_refs`, `required_inventory`, `evaluated_rows`, `policy_ref`. Each evaluated row identifies subject/domain/unit/basis and actual observed/limit data required by that check. These leaf reports cannot contain an execution-record, assessment, attempt-report or receipt checksum. Their detailed metric row variants are the method's exact registered report types, not arbitrary JSON assertions.

Hash order is acyclic: consumed request → source recipe → p-specific realization and retained states → factor/check leaf reports → numerical execution records → assessment → attempt reports → final receipt/raw source → analysis/derivative/export. A higher-level record may refer downward only. State payloads do not include their header/receipt or the final raw hash. Publication leaf reports hash the covered raw numeric rows before receipt insertion; those rows do not contain a raw-envelope checksum. Reject any self/back-reference rather than attempting a hash fixed point.

```
CheckSummary = {
  check_id:Id, policy_ref:ContentRef,
  required_inventory_sha256:Sha256,
  evaluated_inventory_sha256:Sha256,
  required_count:integer, evaluated_count:integer,
  failed_ids:[Id],
  worst:{subject_id:Id, observed:BinaryScalar, limit:BinaryScalar}|null,
  report_ref:ContentRef
}
```

The registry defines exactly the allowed check IDs: `retained_free_equilibrium_v1`, `prescribed_compatibility_v1`, `cross_precision_displacements_v1`, `cross_precision_actions_v1`, `independent_element_energy_v1`, `complete_force_balance_v1`, `complete_moment_balance_v1`, `checked_binary64_projection_v1`. Reports retain each covered subject and its actual observed/limit pair. A successful summary has exact inventory/count equality, no failed IDs, and all covered comparisons passing their bound policy; no comparison can be replaced by a generic pass boolean. `worst` refers to the worst normalized comparison and its actual pair, not unrelated global maxima. Zero limit with nonzero observation fails; zero limit with exact zero passes. If the inventory is empty by the actual source model, worst is null and that check is explicitly vacuous. This permits a fully prescribed model's empty free-equation domain while still requiring actual reaction/publication and prescribed-value checks.

The independent_recovery checks are separate from cross-precision comparison and free-equation residuals. Their execution_ref equals the selected attempt's independent_recovery record; its input state equals independent_recovery.state_sha256 and the selected candidate state. The reference geometry and origin are bound to the source recipe and actual method's predetermined origin-selection rule, not adjusted after observing a failure.

- independent_element_energy_v1 covers every active energy-carrying element/support contribution required by the admitted formulation, with units N*m and quantity_kind elastic_strain_energy. Compare independently evaluated source constitutive energy with the independently recovered elastic deformation/action work under that family's declared reference/eigenstrain law. For a quadratic law use elastic deformation q−qref, not an indiscriminate one-half external nodal work formula. Calling the same recovery routine at two precisions is not this independent computation. Work/energy evidence is not a physical moment row.
- complete_force_balance_v1 covers the complete physical applied-load and support/reaction ledger exactly once, in the model global frame, with signed x/y/z sums and units N. Reactions at prescribed DOFs and spring/device forces must be present. Eigenloads are not duplicated as physical external loads; active pressure/formulation-specific face ownership follows the admitted source contract.
- complete_moment_balance_v1 uses that same force inventory plus applied/support couples and moment arms from the bound reference geometry/origin. It records signed x/y/z sums in N*m. A force balance, free-row residual or agreeing two-precision action set cannot substitute for this check.

Leaf check rows for energy identify element/support, both independent operands, units, method/reference-state basis and observed/limit comparison. Force/moment leaves retain their complete typed inventory, each contribution's identity, sign/frame/position/role and vector, resultant components and actual policy comparisons. Duplicate, missing, wrongly signed or wrong-state ledger entries fail their inventory/balance checks. These reports do not reference the execution/assessment containing them. All three summaries and leaves are mandatory for selected success; they retain the existing method/quantity limits and applicable1e-9 intended-answer criteria. No check is waived or tolerance invented by adding the wire fields.

The publication inventory consists of the recognized structural displacement/action fields expected for this case/formulation, identified by exact raw row ID plus field path/unit. Its digest covers the ordered inventory; projected_raw_rows_sha256 covers those exact raw row/field values and metadata in raw order. Missing required rows, duplicate IDs or omission of the small torque fail. These checks do not claim all uncorrected stress/code/pressure features are qualified; formulation limits remain explicit.

Sensitivity estimate null requires an explicit reason; it cannot imply a favorable estimate. Whether an unavailable estimate can support completion is defined by the adopted method policy and its alternative evidence, never guessed by a consumer. The same rule applies to a mandatory report that is unavailable: preserve inspectability and truthful source claims, but do not assert independent evidence verification or replayability without its payload.

## Validation responsibilities

Rust source-bound completion validates actual computations and constructs the receipt. Rust/Python/TS readers validate exact branch shape, known registry tuples, case/source/state/result correspondence, counts/inventory equality, attempted versus completed precision and status consistency. They do not claim to rerun a matrix factorization by inspecting a receipt. Artifact content verification resolves only the matching known content and checks canonical hashes/schema/bindings; absent content is reported distinctly from a hash mismatch. Existing source/build authentication remains mandatory for Current, independently of these structural validations.

This separation permits old strict readers to remain strict, new consumers to explain genuine extended results, and evidence/replay tools to inspect the exact retained state without requiring every renderer to implement arbitrary-precision linear algebra.

The existing two-argument `numerical_use_standing(source, requested_basis_refs)` has no artifact resolver or actual manifest payload. It may preserve the precision-1 result under its existing contract; **it cannot return extended numerical Current eligibility solely from a precision-2 header/receipt**. Its new semantic branch must either require the additional verified context or return a derived `evidence_unverified`/`retained_state_unavailable` disposition with disabled new recovery/rule-use. This is a consumer standing value, not another raw QualityStatus.

The implementing v2 qualification API therefore accepts the actual captured input-manifest payload/checksum, consumed-request descriptor/checksum and a resolver/content map for the known numerical artifacts. It computes/validates their hashes and associations itself; a caller-supplied `verified:true` is not the API. If metadata is known but evidence unavailable, preserve static inspection and explicitly withhold the stronger current-use/replay result. The existing source/build authentication remains a separate required caller boundary. An async resolver must bind the captured model/request snapshot and recheck currentness before installing a result, preserving the existing stale/interruption guards.

## Revision02 binding clarifications

consumed_solver_request_v1 captures the PRE-normalization typed model, materials override, solver mode/settings and method policy refs before section resolution/unit normalization mutate or round input. Source-energy recipes re-evaluate units/geometry/section/materials from these represented inputs, with any extra resolution source bound explicitly. The original InputManifest and raw/outer run identities retain their meanings.

The extended receipt has exactly the publication object defined in revision02 CONTRACT.md instead of the former top-level publication_profile string. Its backend/version/profile/qualification are independently closed and bound: Astro arithmetic and Dashu publication are separate roles. Assessment.publication.profile_id equals receipt.publication.profile_id. The arithmetic/range/qualification references bind the actual reviewed integrated adapter and dependency closure; old or crossed tuples are invalid. The publication artifact scalar transfer is exact; structural solution correctness remains governed by the existing full method checks.

The real wrapper admits only128/256/512/1024 arithmetic contexts. A selected residual execution at2p satisfies the existing p+64 lower bound; arbitrary intermediate context values remain unsupported. Raw source width may exceed p (up to its admitted bound), but every returned nonzero arithmetic value satisfies its own actual p. Signed zero remains explicit throughout transfer and replay.
