# M38 token input prevention return

Added `autoCapitalize="none"`, `autoCorrect="off"`, and `spellCheck={false}` to only New load case id and New load case kind. Source matched the retained preimage byte for byte before editing. The frozen diff contains six added lines; handlers, values, trimming, label, provenance, status and stored data behavior are unchanged. No contrary evidence was found in the inspected input/state/create-intent path.

The retained observation shows keyboard-versus-paste divergence and changed kind in an unapplied queued draft. It does not establish a native subsystem cause or successful hydrotest application. This change requests text-assistance opt-out; it is not a demonstrated native fix.

Verification is source and diff inspection only. No tests (including attribute-mirroring tests), build, browser/native/GUI, Git, dependency or global-configuration operations were performed. Fresh independent review and ROOT's source-bound native typing/blur/queue witness remain pending, including paste and intentional mixed-case controls. No acceptance or release claim is made.

Frozen source and patch: `_run_records/LoadCaseManagerPanel.tsx.after`, `_run_records/FROZEN.diff`. Exact hashes, instruction/source origins, actual parentage, role and enforcement limits: `_run_records/ORIGINS.json`.
