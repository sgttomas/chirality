# Closed wire types for precision-2

This is the exact field-name companion to CONTRACT.md. It adds no outer document version. All records have closed keys; `?` means nullable/conditionally absent only where specified here. Arbitrary extra fields or renamed kinds are not accepted. The method/semantic registry pins these definitions and actual schema hashes before emission. A ContentRef is data, never an instruction to fetch executable code.

## Scalar and reference primitives

```
Sha256 = 64 lowercase hexadecimal characters
Id = nonempty string
Count = nonnegative JSON safe integer, never a boolean
BasisRef = {ref_type:"load_case", ref_id:Id}
InputManifestChecksum = {
  algorithm:"sha256", canonicalization:"rfc8785_jcs",
  payload_ref:{object_type:"InputManifest", ref:Id},
  payload_scope:"input_manifest", value:Sha256
}
BinaryScalar = {negative:boolean, significand:string, exponent2:integer}
ContentRef = {
  artifact_id:Id,
  schema_id:Id,
  canonicalization:"openpipestress_jcs_ijson_v1",
  sha256:Sha256
}
```

`BinaryScalar` represents (-1)^negative×significand×2^exponent2. Integer strings are unsigned canonical decimal (`0` or positive without leading zeros), odd when nonzero; zero has exponent0 and retains its explicit sign. It is not a generic JSON quantity or a physical moment. Precision and admitted exponent/significand bounds belong to its containing record's registered arithmetic/range profile. Validate string lengths and safe integer exponents before allocating BigInts. Nonfinite values never masquerade as a scalar. The public scientific quantity rows remain unchanged finite f64 value/unit objects. An internal binary-digit ValueRecord is converted exactly to this decimal integer spelling; the negative boolean, including negative zero, is not discarded.

All counts, dimensions, precision sizes and ordinals below are Count with the additional stated bounds; JSON booleans never satisfy an integer check. Exponents are signed safe integers further limited by the admitted range profile. InputManifestChecksum is the existing profile spelling at this inspected basis; an actual differently versioned manifest contract must be explicitly supported, not silently relabelled into this shape.

ContentRef's artifact ID is `numerical-artifact:sha256:<sha256>`. Its digest covers the exact canonical payload identified by `schema_id`; that payload includes its own schema identifier but no self checksum. Existing source/raw/package checksums keep their original structures and meanings. This new internal evidence-link type deliberately has one fixed spelling across Rust/Python/TS rather than inheriting different raw/analysis reference shapes. Registry qualification/range entries resolve these links locally; a result cannot register its own new schema or accepted method by naming an artifact.

Known artifact schemas for this first method are `arithmetic_wrapper_qualification_v1`, `numerical_method_policy_v1`, `numerical_range_profile_v1`, `consumed_solver_request_v1`, `source_energy_state_v1`, `contribution_precision_attempt_v1`, `retained_structural_state_v1`, `contribution_precision_check_v1`, `numerical_factor_report_v1`, `numerical_check_rows_v1`. They are numerical evidence types within precision-2, not additional analysis/result family versions. Unknown schema ID is unsupported. The arithmetic qualification artifact identifies the admitted wrapper/backend/build and tested/proved operation scope; the numerical method policy separately defines structural acceptance and mandatory checks. Range artifacts identify the admitted resource/arithmetic range; a known pending qualification can be reported in an unsuccessful attempt but cannot support selected success. The receipt arithmetic.qualification_ref must target arithmetic_wrapper_qualification_v1, range_profile_ref targets numerical_range_profile_v1, and CheckSummary.policy_ref targets the registered numerical_method_policy_v1 for its method. These are structured JSON registry/evidence payloads; original Markdown/source/test files are linked inside them with their truthful original hash conventions rather than falsely hashed as JCS text.

## Source and state

```
SourceBinding = {
  run_id:Id,
  model_ref:Id,
  input_manifest_checksum: InputManifestChecksum,
  basis_ref:BasisRef,
  formulation_profile_id:Id,
  source_request_checksum:ContentRef, // schema consumed_solver_request_v1
  source_energy_checksum:ContentRef,  // schema source_energy_state_v1
  dof_map_checksum:Sha256,
  source_coverage_checksum:Sha256
}
```

The existing input-manifest checksum object must exactly match the supplied manifest evidence, including algorithm, canonicalization, payload reference/scope and value. No relabelled request/raw/retained-state checksum is accepted in that slot. `source_energy_state_v1` payload contains exactly `schema_id`, `source_binding_without_source_energy_checksum`, `dof_map`, `supported_families`, `elements`, `supports`, `loads`, `constraints`, `coverage`. Its numeric inputs use their actual represented source convention, not rounded displays. Element/support family records are the recognized source-energy adapter records; their maps/parameters/ownership are explicitly registered by the method. Unknown family or a rounded-only legacy matrix has no source-energy qualification. The coverage records identify every required source entity/contribution, not just a total count.

`consumed_solver_request_v1` contains `schema_id`, `input_contract_id`, `model`, `materials_override`, `solver_mode`, `solver_settings` and `method_policy_refs`, using the actual consumed typed values and existing source number conventions. It has no output/raw/run-artifact checksum. Core draft and source-owned finalizer compare that exact descriptor/checksum before binding the caller's real manifest. If the actual invocation context cannot establish the correspondence, a valid completed wire receipt is not fabricated. The source binding's raw run ID and outer consumer alias are not interchangeable.

This source checksum binds the fixed recipe/formulation IDs and exact represented inputs, not precision-specific evaluated matrices or normalized vectors. Rebuilding at p and 2p preserves that source identity while changing the realized matrix/loads. Each attempt therefore additionally records `realization_sha256` (null before assembly), covering its actual evaluated/scaled/reduced equations, precision and maps. Do not force unequal p-bit realizations to claim the same realization hash or permit their different source recipes to hide behind the same model ID.

`retained_structural_state_v1` payload contains exactly `schema_id`, `source_binding`, `precision_bits`, `dof_map`, `global_values`, `basic_deformations`, `recovered_actions`. Global values are ordered BinaryScalars; basic/action records carry exact entity/frame/quantity/DOF or component identity, units and ordered BinaryScalars. The initial registry permits only the supported structural family records. `dof_map` must agree byte-for-byte with the source inventory and its checksum; global values include actual prescribed coordinates. Entity identity, units and array dimensions cannot be inferred from position after a case swap.

The RetainedState header in CONTRACT.md uses ContentRefs in `source_energy_checksum` and `content_ref`, plain Sha256 in `dof_map_checksum`, `state_checksum` and `recovered_structural_rows_checksum`. Its state checksum equals content_ref.sha256. Its precision equals the selected attempt's **candidate_bits**, and its checksum equals the cross-precision candidate checksum. The verification state is separately named; a producer cannot silently publish verification-state values while claiming the candidate state was their source.

## Attempt facts and arithmetic precision

The Attempt fields in CONTRACT.md are fixed. `candidate_bits` names target stored/returned arithmetic precision, not a claim that every internal operation used a same-p Context. An exact intermediate Context(0) is permitted only by the qualified wrapper profile and its input/intermediate size bounds. Its result must be rounded once into the target-p value before returning across the wrapper API.

Every actual attempt report includes these fields:

```
{
 schema_id:"contribution_precision_attempt_v1",
 source_binding:SourceBinding,
 ordinal:integer,
 candidate_bits:integer,
 verification_bits:integer|null,
 residual_bits:integer|null,
 arithmetic_profile_id:Id,
 maximum_returned_significand_bits:integer|null,
 precision_violation_ids:[Id],
 reached_stage:<Attempt.completed_stage>,
 outcome:<Attempt.outcome>,
 failure_ids:[Id],
 realization_sha256:Sha256|null,
 retained_state_checksum:Sha256|null,
 assessment_checksum:Sha256|null
}
```

No operations performed means null maxima, not fabricated zero-bit success. Separate verification report metadata records its actual returned precision; successful candidate results have maximum returned bits≤p, verification≤2p. Dashu's allowed129-bit subtraction result under Context128 is therefore not evidence of fixed-p success. A qualified exact-sum→single-p-round wrapper may repair that contract, but its intermediate precision must not be misclassified as a returned precision violation. Do not assume Context(0) followed by `with_precision(p)` performs the necessary rounding: the observed source does not establish that path. The candidate explicit shared-round operation and IEEE zero-sign handling remain subject to independent qualification. Record real violations/failure IDs, not a false intended precision.

`residual_bits` is also nullable until evaluated. For a selected successful attempt, candidate∈{128,256,512}, verification=2*candidate, residual≥candidate+64 and all operations respect the registered ceiling/range. Attempt state/report/source and receipt fields must agree exactly. Earlier failures need not have factor/state/assessment payloads; null means not reached.

## Assessment objects

Use these exact fields for the six sections of ExtendedAssessment:

```
source_coverage = {
  expected_sha256:Sha256, evaluated_sha256:Sha256,
  expected_count:integer, evaluated_count:integer,
  missing_ids:[Id], extra_ids:[Id], supported_family_ids:[Id]
}
factor = {
  kind:"cholesky"|"ldlt_profile"|"no_free_dofs",
  precision_bits:integer, dimension:integer,
  positive_pivots:integer, nonpositive_pivots:integer,
  unresolved_pivots:integer,
  ordered_dof_map_sha256:Sha256, report_ref:ContentRef
}
retained_equilibrium = {
  state_sha256:Sha256,
  equation_basis:"source_energy_contributions",
  state_basis:"retained_internal_solution",
  free_equations:CheckSummary,
  prescribed_compatibility:CheckSummary
}
cross_precision = {
  candidate_state_sha256:Sha256, verification_state_sha256:Sha256,
  candidate_bits:integer, verification_bits:integer,
  displacements:CheckSummary, actions_and_reactions:CheckSummary
}
publication = {
  state_sha256:Sha256,
  profile_id:"dashu_checked_binary64_projection_v1",
  required_structural_fields_sha256:Sha256,
  projected_raw_rows_sha256:Sha256,
  structural_fields:CheckSummary,
  unrepresentable_ids:[Id]
}
sensitivity = {
  estimator_id:Id|null, basis:Id,
  estimate:BinaryScalar|null, unavailable_reason:Id|null,
  finding_ids:[Id]
}
```

The selected method's structured assessment artifact is `contribution_precision_check_v1`, with `schema_id`, `source_binding`, `retained_state_sha256` and these six objects. It cannot include another method's report or a different case's state. A receipt embeds ExtendedAssessment as above or copies it from that bound artifact; if both exist their canonical bodies must agree. Missing mandatory content yields incomplete verification, never implicit success.

For the attempt report's `assessment_checksum`, hash the canonical object `{schema_id:"contribution_precision_check_v1", source_binding:receipt.source_binding, retained_state_sha256:receipt.retained_state.state_checksum, ...receipt.assessment}`. The embedded six-object body is not independently hashed under a different projection. This fixes the one checksum scope used by both producer and consumers.

Factor.report_ref is a **leaf** `numerical_factor_report_v1`: `schema_id`, `source_binding`, `attempt_ordinal`, `realization_sha256`, `precision_bits`, `kind`, `dimension`, `ordered_dof_map`, `pivot_evidence`, `condition_evidence`, `range_findings`. A CheckSummary.report_ref is a **leaf** `numerical_check_rows_v1`: `schema_id`, `source_binding`, `check_id`, `state_refs`, `required_inventory`, `evaluated_rows`, `policy_ref`. Each evaluated row identifies subject/domain/unit/basis and actual observed/limit data required by that check. These leaf reports cannot contain an assessment, attempt-report or receipt checksum. Their detailed metric row variants are the method's exact registered report types, not arbitrary JSON assertions.

Hash order is acyclic: consumed request → source recipe → p-specific realization and retained states → factor/check leaf reports → assessment → attempt reports → final receipt/raw source → analysis/derivative/export. A higher-level record may refer downward only. State payloads do not include their header/receipt or the final raw hash. Publication leaf reports hash the covered raw numeric rows before receipt insertion; those rows do not contain a raw-envelope checksum. Reject any self/back-reference rather than attempting a hash fixed point.

```
CheckSummary = {
  check_id:Id, policy_ref:ContentRef,
  required_inventory_sha256:Sha256,
  evaluated_inventory_sha256:Sha256,
  required_count:integer, evaluated_count:integer,
  failed_ids:[Id],
  worst:{subject_id:Id, observed:BinaryScalar, limit:BinaryScalar}|null,
  report_ref:ContentRef
}
```

The registry defines exactly the allowed check IDs: `retained_free_equilibrium_v1`, `prescribed_compatibility_v1`, `cross_precision_displacements_v1`, `cross_precision_actions_v1`, `checked_binary64_projection_v1`. Reports retain each covered subject and its actual observed/limit pair. A successful summary has exact inventory/count equality, no failed IDs, and all covered comparisons passing their bound policy; no comparison can be replaced by a generic pass boolean. `worst` refers to the worst normalized comparison and its actual pair, not unrelated global maxima. Zero limit with nonzero observation fails; zero limit with exact zero passes. If the inventory is empty by the actual source model, worst is null and that check is explicitly vacuous. This permits a fully prescribed model's empty free-equation domain while still requiring actual reaction/publication and prescribed-value checks.

The publication inventory consists of the recognized structural displacement/action fields expected for this case/formulation, identified by exact raw row ID plus field path/unit. Its digest covers the ordered inventory; projected_raw_rows_sha256 covers those exact raw row/field values and metadata in raw order. Missing required rows, duplicate IDs or omission of the small torque fail. These checks do not claim all uncorrected stress/code/pressure features are qualified; formulation limits remain explicit.

Sensitivity estimate null requires an explicit reason; it cannot imply a favorable estimate. Whether an unavailable estimate can support completion is defined by the adopted method policy and its alternative evidence, never guessed by a consumer. The same rule applies to a mandatory report that is unavailable: preserve inspectability and truthful source claims, but do not assert independent evidence verification or replayability without its payload.

## Validation responsibilities

Rust source-bound completion validates actual computations and constructs the receipt. Rust/Python/TS readers validate exact branch shape, known registry tuples, case/source/state/result correspondence, counts/inventory equality, attempted versus completed precision and status consistency. They do not claim to rerun a matrix factorization by inspecting a receipt. Artifact content verification resolves only the matching known content and checks canonical hashes/schema/bindings; absent content is reported distinctly from a hash mismatch. Existing source/build authentication remains mandatory for Current, independently of these structural validations.

This separation permits old strict readers to remain strict, new consumers to explain genuine extended results, and evidence/replay tools to inspect the exact retained state without requiring every renderer to implement arbitrary-precision linear algebra.

The existing two-argument `numerical_use_standing(source, requested_basis_refs)` has no artifact resolver or actual manifest payload. It may preserve the precision-1 result under its existing contract; **it cannot return extended numerical Current eligibility solely from a precision-2 header/receipt**. Its new semantic branch must either require the additional verified context or return a derived `evidence_unverified`/`retained_state_unavailable` disposition with disabled new recovery/rule-use. This is a consumer standing value, not another raw QualityStatus.

The implementing v2 qualification API therefore accepts the actual captured input-manifest payload/checksum, consumed-request descriptor/checksum and a resolver/content map for the known numerical artifacts. It computes/validates their hashes and associations itself; a caller-supplied `verified:true` is not the API. If metadata is known but evidence unavailable, preserve static inspection and explicitly withhold the stronger current-use/replay result. The existing source/build authentication remains a separate required caller boundary. An async resolver must bind the captured model/request snapshot and recheck currentness before installing a result, preserving the existing stale/interruption guards.
