# Revision02 return

Ready for fresh independent design review and prospective ROOT selection. Read CONTRACT.md, WIRE_TYPES.md, EXACT_BOUNDARY.md and REVISION_BASIS.md together. The selected parent bytes/ROOT selection and prior reviews remain unchanged; `_run_records/REVISION_02/FREEZE.json` binds this candidate, original preimages, origins and exact contract/wire diffs.

The hybrid names Astro0.3.7 arithmetic and Dashu0.6.0 exact-transfer publication separately, retains signed-zero/range/precision guards, uses actual admitted residual contexts and captures pre-normalization sources. All EC01–03 source/phase/energy/balance checks persist. Actual869 native/WASM scalar evidence is identified without promotion to structural qualification.

NGR02 gets a distinct represented-contribution/exact-ratio, field-specific recovery design. Its first readable branch remains unresolved while retained source/minor/ratio and mixed recovery qualification are absent. There is no synthetic binary64 receipt or source-energy claim; original unsupported cases and1e-9 criteria remain.

Solver WORKING_ITEMS owns source/typed evidence and Python integration; authoring WORKING_ITEMS owns its coordinated TS/store branch. This task changes only design/evidence. Public precision-2 emission, registered schema/table/profile bytes and Current are not implemented by these documents. No new outer version or owner approval is requested.
