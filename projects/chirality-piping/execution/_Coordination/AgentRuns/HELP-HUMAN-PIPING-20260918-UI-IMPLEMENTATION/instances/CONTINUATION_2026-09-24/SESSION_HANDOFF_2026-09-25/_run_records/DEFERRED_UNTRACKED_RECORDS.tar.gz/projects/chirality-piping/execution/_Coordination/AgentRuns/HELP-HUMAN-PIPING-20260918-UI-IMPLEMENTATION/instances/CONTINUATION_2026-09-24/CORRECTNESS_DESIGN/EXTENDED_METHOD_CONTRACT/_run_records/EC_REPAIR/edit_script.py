from pathlib import Path
b=Path('/Users/ryan/.codex/worktrees/6614/chirality/projects/chirality-piping/execution/_Coordination/AgentRuns/HELP-HUMAN-PIPING-20260918-UI-IMPLEMENTATION/instances/CONTINUATION_2026-09-24/CORRECTNESS_DESIGN/EXTENDED_METHOD_CONTRACT')
p=b/'WIRE_TYPES.md';s=p.read_text()
def one(old,new):
 global s
 if s.count(old)!=1: raise RuntimeError('expected exactly one target: '+old[:90])
 s=s.replace(old,new)
one('SourceBinding = {\n  run_id:Id,','SourceBinding = CompleteSourceBinding | IncompleteSourceBinding\nCompleteSourceBinding = {\n  admission_state:"complete",\n  run_id:Id,')
one('  source_coverage_checksum:Sha256\n}\n```','''  source_coverage_checksum:Sha256
}
IncompleteSourceBinding = {
  admission_state:"incomplete",
  run_id:Id, model_ref:Id,
  input_manifest_checksum:InputManifestChecksum,
  basis_ref:BasisRef, formulation_profile_id:Id,
  source_request_checksum:ContentRef|null,
  source_energy_checksum:ContentRef|null,
  dof_map_checksum:Sha256|null,
  source_coverage_checksum:Sha256|null,
  unavailable:[{
    field:"source_request_checksum"|"source_energy_checksum"|
          "dof_map_checksum"|"source_coverage_checksum",
    reason:"interrupted_before_materialization"|"unsupported_source_family"|
           "resource_limit_before_materialization"|"not_reached"
  }]
}
```

Incomplete bindings preserve the actual invocation/manifest/model/case identity and each available completed digest. At least one of the four nullable fields is null; unavailable names exactly the null fields, once each, with an actual reason. A non-null field must identify a genuinely completed corresponding artifact/inventory, never a placeholder or hash of an empty stand-in. Source-energy completion requires admitted family/coverage semantics. Partial payloads are not hashed as a complete source_energy_state_v1. The core no-manifest draft remains internal; this incomplete wire binding is for an actual available invocation context finalized as an unsuccessful result.

An incomplete receipt cannot have a selected attempt, retained state, assessment, source_energy_retained fidelity, checks_passed/sensitive quality or Current eligibility. Its attempt report uses the same union, reaches source_admission, has no phase execution records and has source_incomplete/resource_limit/interrupted/failed outcome. Numeric case status is unresolved or failed, never not_assessed for an actual attempt. Diagnostics may preserve known source facts without inventing complete evidence.

The receipt binding records the latest actually reached admission state. Across attempts the required invocation fields are identical; every earlier non-null digest must match the later binding. Missing fields may become available, but established fields cannot change. Once complete, the source binding is identical for all subsequent attempts. Earlier incomplete reports remain unchanged. Every retained state, realization, execution, factor/check leaf and assessment requires CompleteSourceBinding; only the receipt and early attempt report allow the incomplete variant.''')
one('`source_energy_state_v1` payload contains exactly','`source_energy_state_v1` uses CompleteSourceBinding (with its own source-energy checksum omitted) and its payload contains exactly')
start=s.index('Every actual attempt report includes these fields:')
end=s.index('\n## Assessment objects',start)
s=s[:start]+'''Every actual attempt report includes these fields:

```
{
 schema_id:"contribution_precision_attempt_v1",
 source_binding:SourceBinding,
 ordinal:Count,
 candidate_bits:Count,
 verification_bits:Count|null,
 residual_bits:Count|null,
 arithmetic_profile_id:Id,
 reached_stage:<Attempt.completed_stage>,
 outcome:<Attempt.outcome>,
 failure_ids:[Id],
 executions:{
   candidate:ContentRef|null,
   verification:ContentRef|null,
   retained_residual:ContentRef|null,
   independent_recovery:ContentRef|null
 },
 retained_state_checksum:Sha256|null,
 assessment_checksum:Sha256|null
}
NumericalExecution = {
 schema_id:"numerical_execution_v1",
 source_binding:CompleteSourceBinding,
 attempt_ordinal:Count,
 phase:"candidate"|"verification"|"retained_residual"|"independent_recovery",
 arithmetic_profile_id:Id,
 precision_bits:Count,
 arithmetic_return_count:Count,
 maximum_returned_significand_bits:Count|null,
 precision_violation_ids:[Id],
 realization_sha256:Sha256|null,
 input_state_sha256:Sha256|null,
 output_state_sha256:Sha256|null,
 reached_stage:"assembly"|"factorization"|"solve"|"recovery"|
               "residual_evaluation"|"independent_recovery_evaluation",
 outcome:"completed"|"precision_contract_unresolved"|"range_exceeded"|
         "factor_unresolved"|"resource_limit"|"interrupted"|"failed",
 report_refs:[ContentRef]
}
```

Each non-null executions entry resolves to numerical_execution_v1 with the matching phase/source/attempt/profile; no execution record exists merely because that phase was planned. A started failed phase has its real record/outcome. Candidate and verification records are separately created and hashed, even if some values happen to match. Their reports reference only lower-level factor/check leaves, never their owning attempt/assessment/receipt.

Arithmetic_return_count counts results returned across the qualified target-precision API, not hidden exact intermediates. Zero returns requires maximum=null; positive count requires an observed maximum. Completed phases have no precision violations and maximum≤their own precision_bits when non-null. No operation is invented for a vacuous no-free-DOF phase; its source and no_free_dofs factor/recovery facts must establish that exception. Dashu's allowed129-bit return under Context128 cannot pass as a128-bit result. An exact intermediate Context(0) is permitted only by the qualified wrapper and size bounds; it is distinct from returned target-p values. Context(0)→with_precision(p) is not assumed to round; the explicit single-p-round and IEEE-zero composition needs its actual qualification.

For a selected successful attempt:

- candidate execution is completed at p∈{128,256,512}, reaches recovery, and identifies the actual p-bit realization and candidate output state. Its input_state_sha256 is null because it solves from the fixed source; refinement history belongs to its method reports.
- verification execution is completed at2p (including1024 for a512 candidate), reaches recovery, and identifies its own realization/output state; input_state_sha256 is null for the independently rebuilt solve. Candidate and verification realizations are separately bound, not forced to be equal.
- retained_residual execution is completed at the actually reported residual_bits≥p+64 within the registered ceiling, reaches residual_evaluation, has the candidate output state as input and no output state, and identifies the intended-source realization used for that residual.
- independent_recovery execution is completed at its recorded precision (at least p and satisfying the registered method policy), reaches independent_recovery_evaluation, has the candidate output state as input and no output state, and identifies the source realization and energy/force/moment check leaves actually used.

Attempt.verification_bits is null exactly when that execution entry is null, otherwise equals its precision_bits; residual_bits follows the same rule for retained_residual. A started-but-failed verification reports its actual precision but cannot support selected success. The selected RetainedState and assessment candidate state must equal candidate execution.output_state_sha256; cross-precision verification state equals verification execution.output_state_sha256. Assessment execution references must equal the selected attempt's corresponding entries. Each factor/check report is among that execution's report_refs and agrees on source/state/realization/precision as applicable. Candidate512/verification1024 is valid; candidate1024 is not in this method's schedule.

Early source-admission failure has all four execution entries null, verification/residual bits null, retained/assessment hashes null, and no fabricated arithmetic maximum. Later failures retain any completed/failed actual phase records but cannot select the attempt. These are metadata/binding checks, not consumer re-execution of the solver.
''' +s[end:]
s=s.replace('`contribution_precision_check_v1`, `numerical_factor_report_v1`','`contribution_precision_check_v1`, `numerical_execution_v1`, `numerical_factor_report_v1`')
s=s.replace('Each attempt therefore additionally records `realization_sha256` (null before assembly)', 'Each phase execution therefore records its own `realization_sha256` (null before that phase materializes its equations)')
s=s.replace('Use these exact fields for the six sections of ExtendedAssessment:', 'Use these exact fields for the seven sections of ExtendedAssessment:')
one('retained_equilibrium = {\n  state_sha256:Sha256,','retained_equilibrium = {\n  execution_ref:ContentRef,\n  state_sha256:Sha256,')
one('cross_precision = {\n  candidate_state_sha256:Sha256, verification_state_sha256:Sha256,','cross_precision = {\n  candidate_execution_ref:ContentRef, verification_execution_ref:ContentRef,\n  candidate_state_sha256:Sha256, verification_state_sha256:Sha256,')
one('publication = {\n  state_sha256:Sha256,','''independent_recovery = {
  execution_ref:ContentRef,
  state_sha256:Sha256,
  configuration_basis:"reference_configuration",
  reference_geometry_sha256:Sha256,
  moment_origin:{frame:"model_global", unit:"m", coordinates:[BinaryScalar,BinaryScalar,BinaryScalar]},
  element_energy:CheckSummary,
  force_balance:CheckSummary,
  moment_balance:CheckSummary
}
publication = {
  state_sha256:Sha256,''')
s=s.replace('and these six objects.', 'and these seven objects.').replace('embedded six-object body', 'embedded seven-object body')
s=s.replace('factor/check leaf reports → assessment → attempt reports', 'factor/check leaf reports → numerical execution records → assessment → attempt reports')
s=s.replace('These leaf reports cannot contain an assessment, attempt-report or receipt checksum.', 'These leaf reports cannot contain an execution-record, assessment, attempt-report or receipt checksum.')
s=s.replace('`cross_precision_actions_v1`, `checked_binary64_projection_v1`.', '`cross_precision_actions_v1`, `independent_element_energy_v1`, `complete_force_balance_v1`, `complete_moment_balance_v1`, `checked_binary64_projection_v1`.')
anchor='The publication inventory consists of the recognized structural displacement/action fields expected for this case/formulation'
pos=s.index(anchor)
s=s[:pos]+'''The independent_recovery checks are separate from cross-precision comparison and free-equation residuals. Their execution_ref equals the selected attempt's independent_recovery record; its input state equals independent_recovery.state_sha256 and the selected candidate state. The reference geometry and origin are bound to the source recipe and actual method's predetermined origin-selection rule, not adjusted after observing a failure.

- independent_element_energy_v1 covers every active energy-carrying element/support contribution required by the admitted formulation, with units N*m and quantity_kind elastic_strain_energy. Compare independently evaluated source constitutive energy with the independently recovered elastic deformation/action work under that family's declared reference/eigenstrain law. For a quadratic law use elastic deformation q−qref, not an indiscriminate one-half external nodal work formula. Calling the same recovery routine at two precisions is not this independent computation. Work/energy evidence is not a physical moment row.
- complete_force_balance_v1 covers the complete physical applied-load and support/reaction ledger exactly once, in the model global frame, with signed x/y/z sums and units N. Reactions at prescribed DOFs and spring/device forces must be present. Eigenloads are not duplicated as physical external loads; active pressure/formulation-specific face ownership follows the admitted source contract.
- complete_moment_balance_v1 uses that same force inventory plus applied/support couples and moment arms from the bound reference geometry/origin. It records signed x/y/z sums in N*m. A force balance, free-row residual or agreeing two-precision action set cannot substitute for this check.

Leaf check rows for energy identify element/support, both independent operands, units, method/reference-state basis and observed/limit comparison. Force/moment leaves retain their complete typed inventory, each contribution's identity, sign/frame/position/role and vector, resultant components and actual policy comparisons. Duplicate, missing, wrongly signed or wrong-state ledger entries fail their inventory/balance checks. These reports do not reference the execution/assessment containing them. All three summaries and leaves are mandatory for selected success; they retain the existing method/quantity limits and applicable1e-9 intended-answer criteria. No check is waived or tolerance invented by adding the wire fields.

''' +s[pos:]
p.write_text(s)
print('Repaired WIRE_TYPES EC01–03 with closed admission/phase/recovery-check types.')
