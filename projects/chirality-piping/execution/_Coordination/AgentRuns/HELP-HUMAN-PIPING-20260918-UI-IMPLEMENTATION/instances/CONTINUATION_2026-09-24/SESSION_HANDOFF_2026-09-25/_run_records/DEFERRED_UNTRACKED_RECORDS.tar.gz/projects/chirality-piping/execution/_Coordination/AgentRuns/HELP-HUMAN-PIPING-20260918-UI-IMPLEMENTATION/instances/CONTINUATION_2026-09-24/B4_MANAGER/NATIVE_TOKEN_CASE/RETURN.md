# M38 native token-input handoff

The retained native72 record confirms case changes in two new-case fields before application: lowercase keyboard ID became capitalized, pasted ID stayed lowercase, and kind changed from lowercase while focused to capitalized in the queued unapplied payload. The controlled React path copies input and only trims whitespace. Native text assistance is a plausible cause; platform versus tool transport remains unisolated. DIAGNOSIS.md records the exact boundary and alternatives.

The candidate adds only autoCapitalize="none", autoCorrect="off" and spellCheck={false} to New load case id and New load case kind. Six lines were added; the rest of the source is byte-identical to the preserved preimage. No user-input case normalization, stored-value migration, label/provenance/status change or precision-2 work is included.

- Source: projects/chirality-piping/apps/desktop/src/features/load-cases/LoadCaseManagerPanel.tsx
- Before SHA-256: 397184b478e189e8f76195068c1906c511784e5d91f992c21902501aca616b50
- Candidate SHA-256: f8bc42b1c32b3b1f4147ea464dab9f2f100cdcd7b84277e79a5399471ebb9c6a
- Frozen patch: implementation/_run_records/FROZEN.diff; SHA-256 04347eb23c3d0642227a912b7fc9598fae3426a3d7c0a3b8f641fb56696e8238

Bounded implementation ran as actual TASK /root/authoring_manager/native_token_fix (Astra low); fresh independent review was launched as /root/authoring_manager/native_token_review (Astra xhigh), both through collaboration under this WORKING_ITEMS manager. Their returns/origins stay in implementation/ and review/. The fresh independent review completed with no actionable findings; review/RETURN.md verifies the complete diff, hashes and one-file scope and finds it suitable for bounded manager fan-in. Native prevention remains unproven. Host permissions and coordination limits do not imply separate OS sandboxes.

Manager source/diff equivalence and scoped portability checks passed (_run_records/MANAGER_CHECK.json). No tests, build, Git, GUI, browser/native launch, dependency or global setting changes were performed. Attribute inspection is not native behavioral proof. NATIVE_CHECK.md supplies ROOT's source-bound keyboard/focus/blur/queue, paste and intentional mixed-case actions; native verification and any allocated existing regression checks remain outstanding. The exploratory original draft was never applied and proves no hydrotest primitive/calculation behavior. No root-cause, successful prevention, release or engineering claim is made.

Return owners: ROOT and solver_manager. The one-file source is frozen for review/native handoff; precision-2 implementation remains held for its separate coherent interface handoff.
