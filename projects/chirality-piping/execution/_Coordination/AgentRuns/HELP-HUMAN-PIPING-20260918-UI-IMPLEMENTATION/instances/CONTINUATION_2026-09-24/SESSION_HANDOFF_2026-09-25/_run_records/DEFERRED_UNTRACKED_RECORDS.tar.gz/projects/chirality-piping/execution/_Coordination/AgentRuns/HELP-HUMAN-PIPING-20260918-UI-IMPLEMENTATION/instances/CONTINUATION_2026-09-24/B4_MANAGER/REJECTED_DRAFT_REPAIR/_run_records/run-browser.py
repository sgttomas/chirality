from pathlib import Path
import subprocess,json,hashlib,os,sys
r=Path(subprocess.check_output(["git","rev-parse","--show-toplevel"],text=True).strip());raw=Path(__file__).resolve().parent;e=raw.parent
project=sys.argv[1]
if project not in {"chromium-desktop","chromium-compact"}:raise SystemExit("Unknown project")
out=raw/"BROWSER"/project;out.mkdir(parents=True,exist_ok=False)
f=json.loads((e/"IMPLEMENTATION/_run_records/candidate-v2.json").read_text())
for p,h in f["files"].items():
 if hashlib.sha256((r/p).read_bytes()).hexdigest()!=h:raise SystemExit("Candidate changed: "+p)
port=subprocess.run(["lsof","-nP","-iTCP:5174","-iTCP:5175","-sTCP:LISTEN"],capture_output=True,text=True);(out/"ports-before.txt").write_text(port.stdout+port.stderr)
if port.stdout.strip():raise SystemExit("Existing port owner")
desktop=r/"projects/chirality-piping/apps/desktop";assets=[{"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((desktop/"public/wasm-engine").iterdir()) if p.is_file()]
context=r/"projects/chirality-piping/apps/desktop/src/features/load-cases/LoadCaseManagerPanel.tsx";context_hash=hashlib.sha256(context.read_bytes()).hexdigest()
cmd=["npx","playwright","test","e2e/b4-pipes.spec.ts","e2e/b4-sections.spec.ts","--project="+project,"--grep","B4 Pipes shared section effective-wall rejection|B4 Pipes unbound mill tolerance|B4 Sections mixed-unit direct editing","--workers=1","--max-failures=1","--reporter=list,json","--output="+str(out/"artifacts")]
env=os.environ.copy();env.update({"CI":"1","PLAYWRIGHT_WORKERS":"1","PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH":"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome","PLAYWRIGHT_JSON_OUTPUT_FILE":str(out/"report.json")})
(out/"command.json").write_text(json.dumps({"argv":cmd,"cwd":str(desktop),"env":{k:env[k] for k in ["CI","PLAYWRIGHT_WORKERS","PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH","PLAYWRIGHT_JSON_OUTPUT_FILE"]},"actual_head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"candidate":f,"wasm_assets":assets,"root_owned_m38_context":{"path":str(context),"sha256":context_hash},"expected_cases":5,"limits":"Existing WASM is explicitly identified; no source build or native witness in this run."},indent=2)+"\n")
with (out/"run.log").open("w") as log:res=subprocess.run(cmd,cwd=desktop,env=env,stdout=log,stderr=subprocess.STDOUT)
changed=[p for p,h in f["files"].items() if hashlib.sha256((r/p).read_bytes()).hexdigest()!=h]
(out/"result.json").write_text(json.dumps({"exit_code":res.returncode,"candidate_mismatches":changed,"root_m38_unchanged":hashlib.sha256(context.read_bytes()).hexdigest()==context_hash,"wasm_unchanged":all(hashlib.sha256(Path(x["path"]).read_bytes()).hexdigest()==x["sha256"] for x in assets)},indent=2)+"\n")
port=subprocess.run(["lsof","-nP","-iTCP:5174","-iTCP:5175","-sTCP:LISTEN"],capture_output=True,text=True);(out/"ports-after.txt").write_text(port.stdout+port.stderr)
print(project,"exit",res.returncode,"ports_empty",not bool(port.stdout.strip()),flush=True);raise SystemExit(res.returncode)
