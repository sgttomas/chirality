# Rejected editor recovery — implementation return

Root's prospective `../ROOT_DISPOSITION.md`, under the owner's correctness delegation at `../../../CORRECTNESS_ACTIVATION.md`, resolves the former UX §3.1 snapback requirement for active rejected editors. The original design and assertion history remains preserved; this is Root's delegated technical decision, not a new personal owner ruling. The earlier `DIAGNOSIS_AND_HOLD.md` remains the historical hold account; the hold is now lifted for source/test work only.

The immediate defect was EngineeringTable's explicit `text: captured.before` override after a rejected non-applied outcome. The one-line repair retains raw entered text and the actual diagnostic. Captured before/unit/generation, canonical model protection, cancellation, local validation, async stale ownership and operation routing are unchanged. ModelTree's actual adapter and workspaceSession's read-only causal trace establish that neither needs editing.

Five maintained paths form the candidate: EngineeringTable.tsx, EngineeringTable.test.tsx, ModelTree.table.test.tsx, e2e/b4-pipes.spec.ts and e2e/b4-sections.spec.ts, all beneath `projects/chirality-piping/apps/desktop/`. No new source files. Only the first is product code. The Root-owned LoadCaseManagerPanel.tsx change is untouched.

Three component snapback expectations now require retained numeric/text drafts with existing diagnostic/cancel checks intact. Added checks cover external focus during delayed rejection and the actual Pipe adapter's 100 mm rejection, Cancel and correction/retry from original before=0. Existing stale-generation and local validation controls remain. The adapter regression mocks the operation callback and does not prove real engine/history behavior.

Browser oracle inventory found one explicit old snapback oracle: Sections wall=3 rejection expected input=10. It now requires input=3 and retains error/disabled Undo, with added Cancel canonical=10 and model-hash equality. Pipe shared-section rejection is parameterized at 10 and 100; unbound 10/11 cases now assert exact rejected raw text before Cancel. Shared-section cases additionally reject again, correct to1 in place, Undo to0 with no earlier Undo, verify original hash and Redo to1. Existing error, canonical and history checks remain.

The complete scoped diff and exact bytes are frozen in `_run_records/candidate.patch`, `_run_records/candidate/`, and `_run_records/candidate.json`. Original bytes and native AX failure evidence are preserved in `_run_records/before/` and `basis.json`, with the folder-rename custody map in `CUSTODY.json`.

Verification: scoped git diff --check passed. No tests, TypeScript, build, browser, native or CUA execution occurred; the execution lane remains held. Fail-first candidate tests against original product bytes and then candidate execution are outstanding, followed by affected real browser/native checks. A fresh independent review must cover the disposition and this five-path frozen diff before integration. No Git mutation was performed.

## Test-basis correction, freeze v2

Before execution, manager identified that the new Pipe adapter test had assumed a JSON before payload. Read-only inspection of modelTableAdapter.ts confirms this route emits the captured raw `before: "0"` with separate `unit: "mm"`; only after is JSON. Both new assertions now reflect that actual contract and assert the unit. Product and other checks are unchanged. Initial candidate freeze remains preserved; current exact five-path freeze is `_run_records/candidate-v2.json`, `candidate-v2.patch` and `candidate-v2/`. The two-line delta is `_run_records/test-basis-correction-v2.patch`. No test execution or temporary baseline swap occurred.
