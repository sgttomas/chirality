# Revision02 decision basis and review boundary

HELPS_HUMANS `/root/correctness_design`, actual parent `/root`, delegated-harness-native continuation under the retained full role and current owner correctness steering. This is a design revision, not a replacement record of prior authority. ROOT's parent ROOT_SELECTION.md and selected CONTRACT/WIRE_TYPES remain byte-identical. Their copied preimages, exact diffs and actual origins are under `../_run_records/REVISION_02/`. A fresh independent review and prospective ROOT selection cover this revision before implementation adoption. No reviewer execution is attributed to this author.

## Proposed change

1. Retain the not-yet-emitted precision-2 semantic ID, method policy schedule and outer family reservations. Solver WORKING_ITEMS explicitly confirmed no precision-2 machine schema, table or profile has been generated/frozen/admitted; no deployed semantic bytes are being redefined. Preserve precision-1 readers/hashes, prior selected documents and all failed backend studies.
2. Replace failed Dashu arithmetic tuple with `astro-float-num`0.3.7 / `astro_raw_binary_to_even_ieee_zero_v1`. Replace its top-level publication string with a closed independent block naming `dashu-float`0.6.0 / `astro_exact_binary_to_dashu_binary64_v1` and role-specific qualification ContentRef. Bind both to actual integrated source/dependency identities. This is a prospective receipt-shape revision; exact diffs make it explicit, not an anonymous extra field or a dependency rename.
3. Record actual qualified contexts:128/256/512/1024; residual2p satisfies the old p+64 condition. No unqualified192/320/576 context is implied. Preserve signed zero, actual width/precision, fixed source and independent phase evidence.
4. Bind source-energy to PRE-normalization typed request/materials/settings and re-evaluated source recipes. Previously rounded normalized parameters or K are not exact original physical contributions. Preserve the separate raw run ID, manifest and headless alias conventions.
5. Add the bounded NGR02 design as a separate, initially nonpassing inspectable method. Retain exact represented-source/minor/ratio/projection evidence and explicit per-field recovery; no invention of binary64-internal or source-energy Astro receipts. The already authorized implementation must qualify the complete field/physical method before a passing case policy can be registered. This does not reinterpret ordinary unsupported results.

## Evidence relied upon

Paths in this table are relative to the continuation's SOLVER_MANAGER/NUMERICAL_INTEGRITY, observed in the numerical manager checkout. Actual machine origins/hashes and read extents are retained in the manifest; these are source records to integrate, not assumed primary-checkout files.

| Evidence | Meaning and limit |
|---|---|
| EXTENDED_PRECISION/ASTRO_WRAPPER/{DOMAIN_AND_API.md,CANDIDATE_FILES.json} | Exact input/range/zero/transfer profile, source adapter SHA `a79ea44f153c517bafc5d71d2b46e134944d99a65b5798b581e2aa76fe2f2e6a`; no public profile allocation. |
| EXTENDED_PRECISION/ASTRO_ADAPTER_REVIEW/WRAPPER_SOURCE_REVIEW.md | Independent source/oracle review and generator repair backcheck, SHA `bb1ae3f5915066bf774764f15664a17fb44ed3f9b6d00430227cf35ee0b06e98`. |
| EXTENDED_PRECISION/ASTRO_ADAPTER_REVIEW/WRAPPER_RUNTIME_BACKCHECK.md | Independent actual native/WASM adapter clearance, SHA `7ce7a164f1c960c388d912761fbf49b60ffe9ae89eeb69dd0ebe131bee202509`; no structural/public method activation. |
| EXTENDED_PRECISION/ASTRO_WRAPPER_CHECKS/_run_records/{native_comparison.json,wasm_comparison.json,PARITY_AND_ENVIRONMENT.json,native.tsv,wasm.tsv} | 869 exact observed rows in each report; both raw SHA `798841124854c3d59804ca19eb3ccd14725adb32e3761159954ff80071299d25`; WASM binary SHA `f29cd2ae451ad6a5bc04e298f206c1f09cae9c82fc87cc9138e06f176603a199`. Design author read the comparisons and checked raw hashes; did not rerun or independently compare every row. |
| EXTENDED_PRECISION/METHOD_INTEGRATION/{EXACT_BOUNDARY_RECOVERY.md,EXACT_BOUNDARY_SOURCE_HASHES.json} | Actual represented-source/ratio path, projected member recovery and missing retention. |
| STRICT_GAP_IMPLEMENTATION/NONLINEAR_REVIEW/RETURN.md | Independent NGR02 finding, SHA `913677f7217ef11a6e206ed5df7ae12329a8001050aa60e3e56c3f4120d628d8`. No nonlinear runtime claimed. |

The design consults exact-boundary source around its source snapshot, ratio construction, SPD/free-block response and projection certificate. It does not claim full integrated code review. Adapter library details rely on the already independent source/runtime packet; this task does not repeat primary-source currency research or backend testing.

The earlier Dashu173/context/division and direct Astro comparison records remain unchanged at their solver-owned origins. The rejected paths are not converted into passes: Dashu oversized division and p+1 results, direct Astro subnormal import and zero-sign defects stay explicit. New869 evidence qualifies only the reviewed adapter composition and its admitted scalar domain. Actual structural source/assembly/factor/refinement/actions, precision receipts, stored replay, user workflows and references still require their own implementation evidence.

## Required fresh review and negative controls

Review the complete revised CONTRACT/WIRE plus EXACT_BOUNDARY, not only the tuple lines. Check old selected-byte preservation and absent admitted precision-2 registry; arithmetic/publication role and profile matching; actual context/range/zero rules; pre-normalization capture; all EC01–03 gates preserved; acyclic source/execution/state hashes; NGR02 mixed recovery and nonpassing status. Readers must reject old Dashu-arithmetic tuple presented as this hybrid, crossed publication refs, unknown profile, lost signed zero, unqualified precision, ratio support reaction relabelled as f64 recovery, source-level overclaim, dropped ratio tails/field inventory, and complete-looking metadata without retained content. Old precision-1 bytes/readers remain unchanged.

No product/schema/graph/dependency/Git writes, native/browser operations, Cargo or heavy numerical execution occurred. Only this authorized design subtree changed. Lightweight work was document generation, source reading, exact hash/diff checks and manifests. No Current completion, backend universal proof, physical accuracy, field-recovery acceptance or release is promised.
