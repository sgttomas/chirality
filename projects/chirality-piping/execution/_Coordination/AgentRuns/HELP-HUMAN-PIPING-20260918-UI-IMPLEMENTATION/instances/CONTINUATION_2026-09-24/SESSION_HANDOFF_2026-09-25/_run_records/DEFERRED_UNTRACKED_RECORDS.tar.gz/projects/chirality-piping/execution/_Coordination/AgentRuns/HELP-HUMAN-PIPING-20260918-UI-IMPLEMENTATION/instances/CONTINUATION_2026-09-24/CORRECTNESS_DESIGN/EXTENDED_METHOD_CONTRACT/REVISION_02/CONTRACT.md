# Explicit extended-method evidence contract — prospective revision 02

Prospective revision, 2026-09-24. This revision requires fresh independent review and ROOT selection; the selected prior bytes and authority remain unchanged in the parent directory. No precision-2 schema/table/profile has yet been generated or admitted (solver-manager coordination). This revision updates the prospective un-emitted receipt shape without allocating a new outer version or semantic ID.

Design basis, 2026-09-24, HELPS_HUMANS `/root/correctness_design` for ROOT, solver manager and authoring manager. Only this subtree is authored. Product/consumer source, dependencies, old contracts and frozen fixtures are read-only. ROOT's owner-delegated correctness authority already covers this technical selection; the document records no personal owner approval or completed solver activation. Actual origins/hashes are under `_run_records/`.

## 1. Smallest truthful compatibility change

Select semantic ID **`openpipestress.result_semantics/0.3.0/precision-2`**, with its own immutable semantic table/hash and explicit reader branch. Keep raw mechanics/producer0.2, canonical derivative/analysis/stress-neutral0.3, model0.2 until the separately selected input change. Do not allocate another outer version. Keep `precision-1`'s exact fields, meanings, mappings, fixtures and hash rules unchanged.

This new ID is necessary: current `precision-1` exact-key validators require `M03-INTEGRITY-v1`, the existing six case fields and `represented_equations_retained`. A contribution/source-energy solve with retained arbitrary-precision action recovery is not the same represented-binary64 assessment. Adding anonymous properties while preserving that ID would either fail strict readers or misstate evidence. `precision-2` is an explicitly supported semantic revision within ROOT's already extensible 0.3 carriers, not an `analysis_run.v0.3.precision-2` schema family. [WIRE_TYPES.md](WIRE_TYPES.md) fixes the exact nested field names, scalar/reference encodings and conditional requirements summarized here.

One `precision-2` envelope can contain ordinary binary64, extended source-energy and explicitly declared bounded exact-boundary cases. The last branch has separate field-level recovery semantics and remains nonpassing until its required evidence/policy exists; see [EXACT_BOUNDARY.md](EXACT_BOUNDARY.md). New emission after this integration uses that semantic ID consistently; consumers never fabricate receipts to upgrade historical carriers. The new reader supports old `precision-1` through its original branch; an old reader rejects `precision-2` as unsupported rather than dropping new fields or treating it as a binary64 pass. Unknown methods, wrapper profiles, proof schemas or contradictory ID/hash tuples never fall back to a known method.

## 2. NumericalQuality delta

Preserve the outer field set and scientific-value declarations:

```
numerical_quality = {
  value_representation: "finite_binary64",
  publication_quantization: "none",
  integrity_policy: "M03-METHOD-DISPATCH-v1",
  status: QualityStatus,
  cases: [NumericalCaseV2]
}
QualityStatus = not_assessed | checks_passed | sensitive | unresolved | failed
```

`finite_binary64` describes published scalar values, not internal arithmetic. `none` means no decimal truncation; it does not mean there was no checked final binary64 rounding. The dispatcher is a contract for interpreting per-case evidence, not a numerical algorithm or a replacement for each method's acceptance policy.

`NumericalCaseV2` has exactly the existing `basis_ref`, `structural_status`, `solve_quality`, `model_matrix_fidelity`, `accuracy_evidence`, `evidence_refs`, plus **`method_receipt`**. Keep existing statuses; add only `source_energy_retained` to the fidelity vocabulary. It means the recognized extended method used its bound source-energy model and retained recovery state; it does not mean mathematically exact arithmetic, exact measured physical inputs or agreement with the old rounded matrix.

`method_receipt` is null only when no structural method was attempted. Then the case is `not_assessed`, fidelity `not_assessed`, accuracy `not_claimed`, and has no passing method evidence. An attempted but unsuccessful method has a failure/unresolved receipt. No missing receipt, unfinished case or empty list can imply a pass. `basis_ref` is the actual requested load-case reference; duplicate, omitted, unrequested or wrong-case receipts fail coverage validation.

The case's summaries are computed from the receipt; they are not independently caller-authored pass switches. Keep `evidence_refs` for human-readable emitted diagnostics/results, with exact unique IDs and case references; numerical interpretation never parses Debug strings or infers a method from prose. Existing binary64 diagnostics retain their meaning; new extended diagnostics may summarize typed evidence but are not its source.

## 3. Exact receipt branches

All objects have closed keys and exact discriminants. Method receipts are emitted only from the source-bound internal completion/result types, including failure returns. A string/header/JSON object supplied by a caller cannot manufacture the opaque successful factor/recovery state. Serialized metadata remains a claim until the existing source/build authentication is established.

### Binary64 receipt

```
{
  method_id: "M03-INTEGRITY-v1",
  arithmetic: "binary64",
  precision_bits: 53,
  equation_basis: "represented_binary64_equations",
  residual_state_basis: "binary64_internal_solution",
  recovery_state_basis: "binary64_internal_solution",
  publication_profile: "finite_binary64_identity_v1",
  report_refs: [existing same-case structured/diagnostic evidence IDs]
}
```

This branch preserves the actual binary64 policy and its current source/contribution audit, limits and case eligibility. It does not reclassify a lost intended contribution as accurate. Accept its existing eligible combinations only when every original check and source binding is satisfied. A `precision-2` consumer must not create this receipt itself for an old run. Old genuine `precision-1` runs continue to use their original reader, not a synthetic re-emission.

### Extended receipt

```
{
  method_id: "M03-CONTRIBUTION-PRECISION-v1",
  receipt_schema: "contribution_precision_receipt_v1",
  source_binding: SourceBinding,
  arithmetic: {
    backend: "astro-float-num", backend_version: "0.3.7",
    wrapper_profile: "astro_raw_binary_to_even_ieee_zero_v1",
    qualification_ref: ContentRef,
    range_profile_ref: ContentRef
  },
  equation_basis: "source_energy_contributions",
  residual_state_basis: "retained_internal_solution",
  recovery_state_basis: "retained_internal_solution_before_binary64_projection",
  publication: {
    backend: "dashu-float", backend_version: "0.6.0",
    profile_id: "astro_exact_binary_to_dashu_binary64_v1",
    qualification_ref: ContentRef
  },
  attempts: [Attempt],
  selected_attempt: integer | null,
  retained_state: RetainedState | null,
  assessment: ExtendedAssessment | null
}
```

These new profile names are proposed prospective registry names for the exact reviewed hybrid, replacing the prior unadmitted Dashu arithmetic tuple. They are not admitted by this design. The publication object is closed and names a different backend role; arithmetic.backend cannot name Dashu, and publication.backend cannot silently name Astro. The arithmetic execution profile IDs equal arithmetic.wrapper_profile; assessment.publication.profile_id equals publication.profile_id. Their ContentRefs must resolve to the same integrated adapter/dependency identity under their distinct role-specific qualification specifications.

The arithmetic profile performs exact integer IEEE binary64 decoding or checked normalized raw-bit input; private operand admission; direct Astro ToEven arithmetic at p in {128,256,512,1024}; exact-zero identity/inexactness validation followed by explicit IEEE sign; and actual output precision/width/exponent checks. The publication profile performs exact normalized-bit transfer into Dashu, verifies value/sign/exponent (signed-zero import separately), then guarded normal/subnormal conversion. It performs no Dashu structural arithmetic. It forbids direct Astro from_f64, approximate/intermediate f64 transfer, direct Dashu arithmetic and unrestricted publication shortcuts. Local origin_inexact is creation rounding provenance, never cumulative source error.

The independently reviewed scalar prototype admitted at most8192 significand bits and normalized exponent[-32768,32768]. Its869 native/WASM rows match exactly; this is bounded scalar qualification, not source reconstruction, structural solve/recovery, memory/time or Current qualification. Production registration binds its actual source/lock, range and resource limits, complete integrated review and affected target checks. Earlier failed Dashu arithmetic/direct Astro conversion and signed-zero witnesses remain failures. See [REVISION_BASIS.md](REVISION_BASIS.md).

The profile definitions require actual qualification before registration. Registration binds their exact specification/qualification hashes. An unqualified implementation cannot claim the name merely by setting it in output. Later wrapper/backend changes require a qualified registry revision; changing a dependency version in this object alone is not sufficient.

The receipt's arithmetic block identifies the configured method/profile, including in an early failure. It is not evidence that arithmetic ran. Actual invocation, returned widths and phase completion are asserted only by the separately bound execution records below.

`SourceBinding` is the closed complete/incomplete admission union in WIRE_TYPES. Both preserve the actual `run_id`, `model_ref`, `input_manifest_checksum`, `basis_ref` and `formulation_profile_id`. Complete admission additionally requires actual `source_request_checksum`, `source_energy_checksum`, `dof_map_checksum` and `source_coverage_checksum`; incomplete admission uses null for any of these not yet materialized, with an exact field/reason list. No placeholder hash or empty stand-in is accepted. The source-energy checksum covers the immutable source-energy recipe actually consumed, including represented input parameters/units, geometry/kinematic recipes, loads/eigenloads/prescribed values, material/section basis, support state and contribution ownership. It is not a renamed model hash, precision-specific realization hash or rounded-matrix hash. No absolute local path is a public identity.

Incomplete bindings represent real attempted source-admission interruption, unsupported family or resource failure after an invocation context exists. They can appear in the receipt and early attempt report only, with unresolved/failed quality, no selected attempt, no retained state/assessment and no passing fidelity/Current claim. Every known field stays truthful and available; missing fields are not fabricated to serialize the failure. Later complete-source factors, executions and retained artifacts require the complete branch. Actual no-manifest core drafts remain internal as before.

The source description and ordered DOF/contribution inventories remain recoverable through existing input/run evidence or a bound numerical artifact. A checksum alone does not prove complete coverage, preserve unavailable input bytes or authenticate the source. The producer must compare coverage against the actual supported model before completion. Consumers verify the receipt's run/case/model/manifest/formulation correspondence against their actual request/source context; standalone package verification without that context reports its limit.

Select a source-owned **finalization stage before immutable raw/artifact hashing**. The present core request carries model/materials and has no caller input manifest, so core execution cannot invent that manifest checksum. It returns an internal draft method outcome, bound to the exact consumed request/settings checksum when materialized, which is not yet a valid Current wire receipt. Native/headless finalization supplies the actual manifest/context captured for that request, verifies the available correspondence and seals the actual artifacts/final raw envelope. Complete success requires the full consumed-input match. An early unsuccessful wire receipt may instead preserve the incomplete binding and explicitly unavailable descriptor/source fields; it makes no completed source/Current claim. This stage belongs to the admitted producer implementation, not a generic consumer enrichment step. Direct core harnesses must supply an actual fixture invocation context or retain a draft/unqualified outcome, never invent a production manifest. Only after finalization is the final raw source checksum computed.

`SourceBinding.run_id` is the actual **raw** run ID. The existing fixed `run:preview-linear-static-001` is not silently renamed to a headless outer alias; input/source/case checksums carry the additional binding. Outer analysis/headless aliases remain in the existing origin machinery. Matching the fixed raw ID alone does not identify an invocation. The new `source_request_checksum` in WIRE_TYPES binds the exact PRE-normalization typed model/material override/mode/settings descriptor used by the core and compared at finalization. Capture it before shared-section resolution or in-place binary64 unit normalization mutates it. Re-evaluate unit factors, geometry, material/section resolution and constitutive recipes from this represented source in admitted arithmetic; previously rounded normalized values/K are not exact original sources. Any separately resolved input not determined by the snapshot must itself be included and bound. The descriptor does not replace the caller's original input-manifest identity.

`ContentRef` uses existing SHA-256/checked-canonicalization conventions and a portable artifact identity. It identifies qualification/range evidence, not executable code to load from a document. Consumers resolve only known admitted registry references, never arbitrary URLs or paths supplied by a result. Missing qualification evidence cannot be replaced with the backend's generic test count.

## 4. Attempts and assessment facts

`Attempt` has exactly `ordinal`, `candidate_bits`, `verification_bits`, `residual_bits`, `completed_stage`, `outcome`, `report_ref`. Candidate target precision is 128/256/512, full verification is 2p (maximum1024), and performed residual precision is at least p+64 and within the registered ceiling. The qualified wrapper supports only128/256/512/1024: use2p for retained residual (and, where sufficient, independent recovery), not unqualified192/320/576 contexts. Record the actual selected precision; this does not relax any check. Verification/residual bits are null until their phase is actually entered; a non-null label must match its bound execution record, and does not alone mean completion. Attempt order is chronological with contiguous ordinals starting at0; `selected_attempt` names that ordinal. Invocation identity is fixed across attempts. An incomplete binding may gain genuinely completed fields, but earlier non-null digests cannot change; after complete admission all subsequent source bindings are identical. Earlier partial reports remain historical.

`completed_stage` is one of `source_admission`, `assembly`, `factorization`, `solve`, `recovery`, `verification`, `publication`. `outcome` is one of `selected`, `precision_insufficient`, `precision_contract_unresolved`, `source_incomplete`, `range_exceeded`, `factor_unresolved`, `physical_mechanism`, `negative_energy`, `publication_unrepresentable`, `resource_limit`, `interrupted`, `failed`. Exactly one selected attempt is permitted for a passing/sensitive case. No selected attempt is allowed for failed/unresolved/not-assessed cases. An escalated failed binary64 attempt may remain a diagnostic history item; it must not be converted into the selected extended proof.

`report_ref` points to the actual same-source attempt report. Its four nullable phase refs identify separately bound candidate, verification, retained-residual and independent-recovery execution records, with actual precision/returned-width observations, source/realization/state hashes, outcome and leaf reports. Planned phases have null refs. Selected success requires all four completed phase records and exact cross-links to the assessment/retained state. Candidate128 and verification256 have separate width limits; candidate512/verification1024 remains valid. A p+1 return cannot hide behind a claimed context precision. In an early incomplete admission all phase refs, verification/residual bits and state/assessment fields are null. A selected attempt's report, state and assessment form one coherent package; earlier failures retain their actual stage and available records without being rewritten as success.

`ExtendedAssessment` contains exactly:

- `source_coverage`: expected and evaluated contribution/constraint/load inventory checksums, expected/evaluated counts, missing/extra IDs and source-supported-family IDs. All required inventories match, no missing/extra contributor exists. A numeric count alone is insufficient.
- `factor`: actual positive structural factor kind, precision, dimension, positive/nonpositive/unresolved pivot counts, ordered-DOF-map checksum and report ref. A known SPD-producing algorithm on the admitted passive formulation is required. No generic LU closure or copied pivot vector can claim this evidence. This is checked numerical factor evidence, not certified exact inertia.
- `retained_equilibrium`: explicit intended-source/free-row domain, retained-state checksum, its actual residual execution ref, evaluated/required DOF coverage, comparison-policy ref, worst error metadata and actual report ref. Constrained residuals are reactions; imposed-value compatibility is a separate covered check. Do not substitute the residual of rounded K or the public displacement projection.
- `cross_precision`: separate candidate/verification execution refs and state checksums, actual precisions, comparison-policy ref, displacement and action/reaction coverage IDs/checksums, evaluated/required counts, failing IDs and worst comparison metadata. Both domains must complete; a global displacement norm or planned precision label is insufficient. These are comparisons of two actual solves, not the independent energy/balance observations below.
- `independent_recovery`: its actual execution ref, selected state, bound reference geometry/common moment origin, and separate element-energy, complete force-balance and complete moment-balance CheckSummaries. They cover source contributions and support reactions independently of the two-precision recovery comparison, with explicit N*m energy, N force and N*m moment roles. Use elastic deformation/reference-state conventions; do not equate arbitrary external nodal work with strain energy or count eigenloads twice as physical loads. These required method checks are now encoded, not waived.
- `publication`: retained-state checksum, structural-result coverage checksum, projected raw-row subset checksum, projection-profile ID, evaluated/required field counts, unrepresentable field IDs and report ref. It binds values computed from retained recovery to their exact published row IDs/fields, units and case. The required structural fields are the recognized displacement and element/support action fields for the supported formulation, including derived vector norms; a producer cannot omit a troublesome torque from the required inventory.
- `sensitivity`: registered estimator/basis, actual estimate or explicit unavailable reason, and sensitivity finding IDs. This does not assert guaranteed forward digits or physical accuracy.

Each structured check's worst-error metadata names its quantity/domain, observed value, actual limit and limit-policy reference. Use a precision-safe scalar representation for numbers not faithfully representable as f64; do not turn an unrepresentable tiny residual or threshold into zero. Exact field names for existing structured report metrics should be reused; the receipt binds their typed reports, not copied human summaries. Report schemas and mandatory checks are pinned by the registered method policy; arbitrary report kinds, counters without inventory binding or a bare `passed:true` are invalid.

Acceptance requires every method-required comparison to have been performed and satisfied under its actual policy. This contract does not invent new thresholds. The independently adopted intended-answer1e-9 checks remain unchanged where applicable. Cross-precision agreement remains operational evidence; it does not by itself set `accuracy_evidence=reference_verified`. That label requires an actual applicable independent reference and its covered quantity/case evidence. Backend scalar qualification is not such a structural reference.

## 5. Retained-state storage and publication

The selected extended receipt embeds a compact retained-state header and an exact content reference:

```
RetainedState = {
  encoding: "normalized_signed_binary_v1",
  precision_bits: integer,
  source_energy_checksum: ContentRef,
  dof_map_checksum: Sha256,
  state_checksum: Sha256,
  content_ref: ContentRef,
  recovered_structural_rows_checksum: Sha256
}
```

The content is a source-bound ordered global solution and/or complete supported basic-deformation/recovery state, sufficient to recompute the covered actions without subtracting public f64 values. Its exact representation is `(-1)^negative * significand * 2^exponent2`, with explicit boolean sign, unsigned integer significand serialized as a string and integer exponent. Normalize nonzero significands to odd values; zero has significand `0` and exponent0 while preserving the explicit sign. This matches the developing wrapper's signed-zero ValueRecord rather than the older prototype's sign-losing pair. Admit exponent/significand/array sizes before expensive integer parsing, using the registered production range/resource profile; the prototype's test range is not an automatic production limit.

The hash covers the actual normalized payload, its format, precision, source/case and DOF/element maps; no checksum includes itself. Use the existing checked canonical JSON profile for JSON payloads, with immutable version-qualified projection definitions. Link raw/source/run records rather than replacing their checksums. Raw mechanics and each derivative retain the receipt and exact content reference; the local run store must preserve the selected content transactionally with the run. An incomplete write/interruption cannot expose a receipt as having persisted replayable content.

Receipt/schema/source eligibility and content availability are distinct. A known authentic completed result with matching receipt can remain inspectable if its external retained artifact is unavailable. Its consumer must report `retained_state_unavailable` and refuse recomputation/recovery from rounded public displacements. A local **new Current solve completion** requires the selected retained content to have been written and checksum-verified; reopening verifies its association. A detached read-only export can remain a truthful numerical-result record with a declared non-replayable limit, but cannot be used as a source for new recovery/combined-state calculations that require the missing content. Never fabricate the state from its header.

Published values are f64 views rounded from the checked retained numerical result, not guaranteed correctly rounded exact mathematical solutions. For the proposed hybrid publication adapter, the profile includes exact Astro-to-Dashu normalized-bit transfer, explicit signed-zero handling, conservative above-maximum rejection and normal conversion rules and guarded subnormal `quantize(-1074)` followed by exact conversion. Preserve the qualified zero/overflow/underflow outcomes; do not use unrestricted `to_f64` or silently write zero for a required unrepresentable nonzero action. The actual wrapper profile must be independently qualified before use.

JCS canonical numeric hashing can collapse the sign of zero. The retained state's explicit sign therefore remains part of its own content hash, and the publication check must inspect the qualified f64 bit/zero behavior rather than infer it from a raw-row JCS checksum alone. Existing canonicalization algorithms/historical hashes are unchanged. A consumer that normalizes public zero must disclose that conversion and cannot claim exact signed-zero replay from the normalized value.

If a public-projection residual is calculated, label it separately as `published_binary64_projection` and retain its own source/field identity. It neither replaces the retained-state gate nor invalidates an accurate internal action simply because equal rounded global rotations cannot reconstruct it. No consumer may silently rederive stress, actions, combinations or support state from those rounded globals when the method requires retained state.

## 6. Status rules and current-use qualification

`checks_passed` or `sensitive` with the extended method requires: known tuple/profile/policy; complete admitted source and case coverage; a selected attempt with separately completed/bound candidate, verification, residual and independent-recovery executions; valid positive factor and retained-equilibrium evidence; complete displacement **and action** cross-precision checks; independently recomputed element-energy plus complete force/moment balances; covered publication with no required unrepresentable field; and matching selected state/report/result bindings. Set fidelity `source_energy_retained`. Do not reuse `represented_equations_retained` for that different claim. Incomplete admission can never satisfy this predicate. Backend precision-contract uncertainty, missing source, inconclusive factor/range/resource limits or an uncompleted required comparison yields `unresolved`, with actual reached-stage evidence. Physical mechanism/negative-energy claims require their existing independent witnesses, otherwise remain numerical uncertainty.

Aggregate exactly as existing ordering: failed > unresolved > not_assessed > sensitive > checks_passed. Coverage is the actual nonempty requested load-case set, not cases that happened to produce rows; no duplicate IDs or silent skipped case. An individual successful case remains identifiable when another case fails, but a partial result set is not a passing all-requested-case envelope. Unknown receipt/semantic method yields `unsupported` interpretation, not a fallback status of pass.

`numerical_use_standing` and its Rust/TS equivalents dispatch first by the exact source/semantic tuple, then by method receipt. Numeric eligibility is still separate from model/input freshness, source/build authentication, mechanics completion and physical formulation applicability. New precision does not qualify pressure/bend/stress features left unsupported. A checksum match or a receipt's correct shape alone establishes none of those claims. Current/rule-use gates require the caller's actual source/request context; standalone validation explicitly states when correspondence was not checked.

## 7. Consumer and implementation order

1. ROOT records the selected `precision-2` semantics and method-policy/profile registrations after this bounded independent review. Freeze the exact semantic-table hash and structured receipt/report/state schemas together. No guessed hash is placed in this document. Existing `precision-1` implementation/freeze continues independently until this new slice is actually integrated.
2. Solver manager integrates the exact reviewed Astro/Dashu adapter into typed method attempts/completion/retained-state/report outputs. The869-case scalar native/WASM evidence is qualified at its bounded adapter scope; earlier173-case Dashu evidence does not qualify the failed full arithmetic tuple. Source-energy reconstruction, factor/solve/refinement, retained actions, structural references and full integration remain required before completed emission. Implement the separate exact-boundary retention repair under EXACT_BOUNDARY.md; do not substitute its represented-source proof for the source-energy method.
3. Rust producer emits honest `precision-2` receipts from those types. Native/headless bind actual case IDs and source/build context. Only then integrate analysis/Python, canonical derivative/Rust, stress-neutral/Python and TS exact branches, with identical known discriminants and no changes to old strict validators.
4. Authoring manager adds new types/standing/display and transactional retained-artifact persistence through its agreed native/store interface. All new containers copy the receipt metadata exactly and verify source correspondence when claiming it; all run/package hashes bind the new fields under their existing family rules. Retained-state availability is shown separately from static-result readability. Export either carries the selected content or declares the exact required content reference/availability limitation; no silently empty artifact.
5. Complete negative controls and actual same-source core/native/headless/store/reopen/export/rule-use checks, then full-diff/candidate review under ROOT's leases. No product change/test/build/GUI/dependency mutation is performed by this design task.

Required negative controls: old strict precision-1 reader rejects precision-2; new reader leaves old bytes/hash behavior unchanged; unknown method/profile/policy/ref rejected; mixed case methods validated independently; correct header with forged/missing receipt cannot bypass source authentication; swapped case/source/DOF/state/report checksum fails; p+1 precision violation cannot pass as p; planned verification cannot count as executed; displacement-only cross-precision checks do not satisfy action coverage; lost N06 torque after early f64 conversion fails; subnormal double-rounding control remains unchanged; missing state blocks replay/new recovery; interrupted persistence never appears complete; a checksum-matching detached artifact is not a current model/build proof; ordinary f64 receipts remain subject to their original checks.
