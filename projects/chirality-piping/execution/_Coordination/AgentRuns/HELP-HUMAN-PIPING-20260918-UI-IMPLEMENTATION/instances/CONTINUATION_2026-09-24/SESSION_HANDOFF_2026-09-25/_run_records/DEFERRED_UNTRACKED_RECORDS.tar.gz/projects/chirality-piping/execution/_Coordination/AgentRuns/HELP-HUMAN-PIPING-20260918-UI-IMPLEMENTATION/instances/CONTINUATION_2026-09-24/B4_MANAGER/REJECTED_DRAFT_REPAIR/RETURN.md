# Rejected table draft recovery — manager return

**Minimal repair, independent source review and local affected checks are complete. Native repaired-artifact verification remains open.** Source basis918b9f158d861e21ad6b0f4d6f25af2407328fd6 includes integrated Pipes and first-correctness changes. The five-path candidate is `SOURCE_WHITELIST.json` / `IMPLEMENTATION/_run_records/candidate-v2.json`, diff SHA-256 `5a060c986931d53bfd03f2ebb3ba7c175507b407434bce293c55f913bcc9e7a3`. ROOT's unrelated LoadCaseManagerPanel M38 patch was not edited and remained byte-identical during browser checks. ROOT owns native, Git/index, graph and final actual-candidate CI/sweep/integration.

## Cause, authority and repair

Native AX19 showed the active Pipe mill-tolerance draft100mm; AX20 showed0mm in the same still-focused invalid editor after OP-SECTION-BINDING-INVALID. The canonical model and history were protected. The source cause is direct and local: EngineeringTable's rejected/non-applied completion branch explicitly replaced `current.text` with `captured.before`. The actual ModelTree adapter and controller preserved the submitted100, before0 and unitmm, then rejected before canonical publication. Row reconciliation/refocus is not the cause.

The older adopted UX_SPEC_V1 §3.1 explicitly required engine-rejected text snapback. That literal/hash, old tests and native baseline remain preserved. After this conflict was disclosed, ROOT prospectively selected raw-draft retention under the owner's application-correctness delegation in `ROOT_DISPOSITION.md`; the later Sections brief was not misrepresented as a personal owner reversal. This replaces only active-editor text snapback, not validation, canonical/before basis, history/result standing or protected numerical/UI criteria. No fresh owner prompt was needed for the delegated choice.

The production repair removes only the explicit text override. Pending clears and the same diagnostic remains; attempted raw text stays available for correction/retry. Captured before/value/unit/generation and ownership guards remain unchanged. Cancel closes the edit and displays the prior canonical value. No adapter, workspaceSession/controller, engine, geometry, M38 or unrelated-family product code changed.

Four maintained test paths accompany the one product path: EngineeringTable and ModelTree table unit tests, plus Pipes and Sections browser specs. Old ordinary snapback expectations were updated under the disposition while retaining/strengthening diagnostic, canonical, Cancel, retry, history and asynchronous-focus checks. A prepared test's JSON-before assumption was caught by manager/reviewer source inspection and corrected to the actual table payload `before:"0", unit:"mm"`; this test-only correction is versioned, not hidden.

## Actual evidence

| Check | Outcome |
|---|---|
| Native baseline | Original AX19/20 and original source bytes are copied and hashed under `_run_records/`; ROOT retains the full native screenshots/build packet. No repaired native run was performed here. |
| Bounded fail-first | With only the owned original EngineeringTable bytes temporarily restored, all4 selected retention cases fail on the old text reset. New tests and the ROOT disposition supply the prospective criterion. The independent reviewer was paused for the temporary swap; `finally` restored the exact v2 source before review/checks resumed. Commands, both hashes, failures and restoration proof are in `_run_records/CHECKS/`. |
| Focused UI / typecheck |133/133 passed across five maintained suites; TypeScript exit0. The candidate stayed frozen. |
| Browser |10/10 passed, five affected Pipe/Section scenarios in each of desktop and compact source projects, one worker per invocation. No skipped/flaky/unexpected result or retry. Exact identities/reports/commands are `_run_records/FINAL_MATRIX.json` and `_run_records/BROWSER/`. Each project exited0 and ports5174/5175 were free. Existing operation-WASM bytes are explicitly hashed; no WASM/native/package build is claimed. |
| Review |Fresh independent Astra/xhigh review covers the prospective disposition and complete five-path diff, including the v2 test correction. No unresolved actionable finding. `REVIEW/RETURN.md` and its raw manifest bind the source and evidence. |

The real browser cases assert rejected raw text before Cancel, canonical hash/history preservation, corrected retry and Undo/Redo; Sections retains raw3 after its coupled rejection and returns to canonical10 on Cancel. The new model-table component tests also bind before0/unitmm/after100 and distinct retry operation IDs, with callback mocks explicitly distinguished from the actual browser operation route. Existing asynchronous generation/token, stale basis, external focus and local-validation checks remain active.

Independent source tracing confirms workspaceSession's non-applied return precedes canonical commit, history receipt/checkpoint, result, analysis-run, input-manifest and solve-job clearing. The one-line local editor change does not alter those guards. Actual repaired native value/focus/result standing must still be witnessed by ROOT; browser/component/source evidence does not substitute for it.

## Provenance and handback

Manager `/root/native_pan_manager` is WORKING_ITEMS/Astra-high. Actual repair writer `/root/native_pan_manager/rejection_draft_repair` is TASK/Astra-low; independent reviewer `/root/native_pan_manager/rejection_draft_review` is TASK/Astra-xhigh. Delegation is harness-native, no Type2 descendants. The intended full TASK role was read before dispatch; instruction hashes match the previously supplied Root/project/role/skill bytes. The manager's temporary baseline swap is verification work, not attributed to the implementation TASK. Original custody mislabeled `structural_run_records` was corrected byte-for-byte to `_run_records` with an exact map; original basis bytes are unchanged.

CPU/browser lane and product-file ownership are returned to ROOT. All owned check processes exited; no browser server remains. No native application action, Git mutation, index or graph write occurred. ROOT should build the exact integrated candidate and repeat rejected100→retained100, Cancel→canonical0, correction/retry and unchanged rejected model/history/result standing, then satisfy actual-candidate CI, cleanDEC-025 and integration gates. This is no engineering/practitioner acceptance, timing qualification or release.
