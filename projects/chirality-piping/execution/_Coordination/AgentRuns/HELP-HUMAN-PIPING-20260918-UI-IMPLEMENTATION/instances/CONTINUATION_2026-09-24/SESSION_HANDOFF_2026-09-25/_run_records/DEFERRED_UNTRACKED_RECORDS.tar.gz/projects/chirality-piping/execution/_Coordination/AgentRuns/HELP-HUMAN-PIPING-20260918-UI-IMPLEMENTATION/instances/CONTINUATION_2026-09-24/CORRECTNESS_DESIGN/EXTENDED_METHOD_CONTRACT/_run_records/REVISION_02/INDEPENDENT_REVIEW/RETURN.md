# Independent Revision 02 design/interface review

2026-09-24. TASK `/root/extended_revision02_review`, parent `/root`, fresh-context delegated-harness-native review.

**PASS at prospective design/interface scope. No blocking finding in the frozen five-file Revision 02 design.** It is suitable for ROOT's prospective selection and bounded manager implementation. This does not admit any public profile, establish retained runtime recovery, close NGR-02 in product code, qualify rotational gap inputs, or authorize Current/result activation. No fresh owner numerical-method prompt is required under the existing correctness delegation.

## Reviewed boundary and identity

Let C be `projects/chirality-piping/execution/_Coordination/AgentRuns/HELP-HUMAN-PIPING-20260918-UI-IMPLEMENTATION/instances/CONTINUATION_2026-09-24`, E be `C/CORRECTNESS_DESIGN/EXTENDED_METHOD_CONTRACT`, and N be `C/SOLVER_MANAGER/NUMERICAL_INTEGRITY`. Design inputs were read in the primary checkout. Numerical evidence and targeted source dependencies were read in the numerical-manager checkout; actual origins and read extents are in MANIFEST.json.

Read all five `E/REVISION_02` files, the full retained selected CONTRACT/WIRE_TYPES/ROOT_SELECTION and prior EC01–03 backcheck, the original selection/checkpoint records, both exact deltas, freeze and origins. All 15 FREEZE entries match; all seven preserved selected preimages are byte-identical to their current parent records. Both stored unified diffs exactly reproduce from the selected preimages and revised files. All 24 designer-observed source hashes still match their actual origins at the check.

| Frozen design | SHA-256 |
|---|---|
| CONTRACT.md | ba2f289633d48be804b88d7a828307ba9d86235ad51115efe5773bbb7de05d25 |
| WIRE_TYPES.md | 117cfee8ad019d69f629449dd04b2b9638263b785418af61de730ced424af85a |
| EXACT_BOUNDARY.md | dc929d0643b3e56deb76dcd31be4bcd3bcc72d27fae661fadc881a69b990bf2b |
| REVISION_BASIS.md | b15ae8e4559641e6c97e9717a13e037d1e0dece92e6723e96057c467e3291a36 |
| RETURN.md | 4a5350a5258b61c29e29846cde4b451789b69b90ce28e4e9ebf3f443e37c97e0 |

The author records that no precision-2 schema/table/profile has yet been emitted, frozen or admitted, based on solver-manager coordination. This review relies on that explicit coordination record; it did not scan every worktree for an undisclosed registry. The old precision-1 branch and selected historical design bytes are preserved. The new receipt shape is a prospective revision under the existing semantic/outer-family reservation, not a silent reinterpretation of deployed bytes.

## Design conclusions

**Prior EC01–03 safeguards survive.** CONTRACT:95–129,161–175 and WIRE_TYPES:39–88,94–153,155–243 retain truthful incomplete admission, fixed invocation identity, monotonic known source facts, null unentered phases, actual precision/returned-width records, separate candidate/verification factors and state identities, and mandatory independent energy/force/moment leaves. The diff changes the arithmetic composition and publication role without deleting those requirements. Candidate 128/256/512 and verification/residual 2p remain within the actual 128/256/512/1024 wrapper contexts; unqualified 192/320/576 contexts are not implied. The complete source branch, selected state and every required comparison remain necessary for success. Energy is N*m under the elastic reference/eigenstrain law; force is N and moment is N*m with a bound predetermined origin. Equal results from two precision runs cannot replace those independent observations.

**The hybrid tuple describes the reviewed adapter rather than the rejected arithmetic.** CONTRACT:66–93,153 and WIRE_TYPES:34,92,140,198,259 separate Astro 0.3.7 arithmetic from Dashu 0.6.0 exact transfer/publication, with role-specific qualification refs and matching integrated source/dependency identities. Exact IEEE decoding, checked raw inputs, direct ToEven, exact-zero identity/inexactness defenses, explicit sign, target width/precision and range checks match the independent source/runtime packet. Dashu structural arithmetic and direct Astro f64 import remain excluded. The prior failed division/context/subnormal/zero witnesses are not rewritten as passes.

The two retained raw scalar reports each have 869 lines and identical SHA-256 `798841124854c3d59804ca19eb3ccd14725adb32e3761159954ff80071299d25`, matching their summaries and the independent runtime backcheck. I read the independent source/oracle and runtime backchecks and verified raw identities/counts; I did not rerun the adapter or independently recompare all numeric rows. That evidence supports this exact bounded adapter composition only.

**Source and replay identity remain coherent.** CONTRACT:97–107 and WIRE_TYPES:76–88,255–261 require the actual pre-normalization typed model/materials/settings descriptor before section resolution or in-place unit conversion. Additional resolved sources must be bound. This prevents the previously rounded normalized matrix or parameters from being labelled original source energy. Raw run ID, outer alias, input-manifest identity, source recipe, p-specific realization, selected/verification states and published-row checksum retain distinct roles. The source-owned finalizer precedes immutable hashes. The source → state → leaf → execution → assessment → attempt → receipt dependency order remains acyclic, with self/upward references excluded.

Signed zero is explicit in retained scalar content, while the unchanged JCS raw-number checksum alone cannot prove its public sign. Selected content must persist transactionally and verify on reopen; missing artifacts preserve inspection with an explicit unavailable standing, not recovery from rounded globals. WIRE_TYPES:245–253 correctly prevents the old two-argument standing helper or caller-supplied `verified:true` from manufacturing extended Current eligibility.

**NGR-02 is a separate and initially nonpassing method.** EXACT_BOUNDARY:7–9,37–55 matches the retained nonlinear finding and the inspected helper/adapter source. The helper's basis is represented frame/spring stiffness contributions, aggregate nodal-force entries, full original partition/K_fc and prescribed values. It does not reconstruct primitive load tails or source energy. Its exact positive minors and response ratios currently live in Context/Response, while the flattened ExactGapReport omits that retained basis. The proposed source/response/projection/iteration/state/field artifacts address this concrete loss rather than claiming it already repaired.

EXACT_BOUNDARY:48–61 preserves full ordered expansion tails, positive denominators, all free-block warrants, every displacement/reaction ratio, exact contact operands/signs, quantity/DOF/unit binding and checked publication. Source refs may vary with actual contact state while invocation identity stays fixed. Failed/unsupported iterations and budget reservations remain visible. The equations for singleton and symmetric 2x2 blocks and exact reactions are consistent with the inspected implementation and scoped represented-equation claim.

Field receipts distinguish ratio-derived global displacement/support reactions from projected-binary64 element/basic/stress recovery, with exact input-state and projection/report references. Derived norms require their own actual derivation evidence. The required inventory includes small torques, spring/member actions and derived fields. The neighbor witness correctly preserves the distinction between exact reaction `-25/2^54` and `-25/2^53` obtained using the published displacement. This review relies on the retained independent control; no solver execution occurred here.

EXACT_BOUNDARY:13,39–41,63,69 prevents this readable branch from yielding checks_passed/sensitive, Current, rule-use, source-energy fidelity or a synthetic binary64 receipt. Retention, complete field coverage, ordinary/exact/projected checks, force/moment and relevant energy/recovery evidence, source/build/currentness, actual nonlinear/product validation and post-context-drop replay remain dependencies of any later passing-policy registration. A source/header/shape check cannot close them.

## Known source prerequisite received during review

ROOT supplied a new product-source finding during this review. I corroborated the current numerical-checkout code: `core/product_physics/src/lib.rs:9848–9855` accepts Rx/Ry/Rz through parse_dof; `:4865–4875` normalizes every nonlinear.gap as Dimension::Length; `:3538` passes the resulting scalar to NonlinearSupport::gap with the chosen DOF. This is a concrete dimensional mismatch for rotational gap use. The reviewed source SHA is `10a8d2195e4cd3674261251fb6e97106ab16ccabd46df60d346e7f6cd42bb645`.

This is a solver-owned implementation/admission prerequisite, not a defect introduced by the prospective receipt design or evidence that an angular workflow works. The design's initial nonpassing rule and field/unit/formulation gates cannot be used to admit this length-only product path as a rotational gap. Before any passing product policy covers rotational gaps, the producer must establish dimensionally correct source normalization and binding, or explicitly reject that family, with appropriate source review and actual checks. A DOF-agnostic exact helper is insufficient. No runtime probe, repaired code, angular qualification or new owner hold is claimed here.

## Return and limits

ROOT may select these frozen prospective design bytes under CORRECTNESS_ACTIVATION and the existing delegation. Solver and authoring managers own coherent source/schema/registry and store/reader implementation. Final exact payload schemas, immutable semantic/profile/policy hashes, integrated source/dependency review, negative controls and actual core/native/headless/store/reopen/export evidence remain required before emission/admission. This review does not preapprove any later passing exact-boundary policy.

Only RETURN.md and MANIFEST.json were written in the assigned temporary review directory. Work was full-document/diff review, targeted source reads and standard-library hash/byte/diff verification. No tests, builds, native/browser activity, network access, Git mutation, product/design edit, or delegation occurred. No engineering acceptance, release or general arithmetic/physics correctness claim is made.
