# Rejected draft diagnosis and prepared repair hold

TASK Type 2, delegated-harness-native, parent `/root/native_pan_manager`, child `rejection_draft_repair`, Astra/low. No delegation. Basis and original bytes: `_run_records/basis.json` and `_run_records/before/`. REPO_ROOT was resolved with Git. Product writes are limited to EngineeringTable.tsx; maintained tests are EngineeringTable.test.tsx and ModelTree.table.test.tsx. Root-owned LoadCaseManagerPanel.tsx is untouched.

## Observed failure and cause

Preserved original native accessibility snapshots `_run_records/19-invalid-draft-before-apply.ax.txt` and `20-invalid-draft-after-apply.ax.txt` show the same focused Pipe mill-tolerance editor changing from 100 to 0 on OP-SECTION-BINDING-INVALID. Native model/history observations are parent-supplied, not newly executed by this child.

ModelTree.tsx apply builds the quantity intent from entered text and captured before/unit. App.tsx maps the owned non-applied outcome to rejected:true. workspaceSession.ts handleApplyIntent returns false for non-applied outcomes before appending applied receipts/undo or committing the model. EngineeringTable.tsx apply then uniquely overwrites current.text with captured.before in its rejected-and-not-applied branch. Other failures preserve text. This explicit override is the immediate cause (high confidence); neither adapter nor controller requires repair.

## Prepared change, held

The one-line product change removes only the text override, keeping the diagnostic, captured basis, pending state and stale ownership guard. Three historical numeric/text snapback assertions become entered-value retention assertions with diagnostics preserved. Added maintained tests exercise Pipe 100 mm rejection/cancel and correction/retry from original before=0, plus asynchronous rejection without external focus theft. Existing stale-generation and local-validation checks remain. The Pipe test uses the real adapter and mocked operation callback; it does not claim real engine/history execution.

The original implementation and assertion bytes remain in the before snapshot. `_run_records/prepared-held.patch` and `prepared-held-hashes.json` freeze the prepared three-path delta. No tests, build, browser, native, CUA, Git mutation or shared controller edits have run.

## Authority conflict

The adopted design-run UX_SPEC_V1.md §3.1 explicitly states that an engine-rejected cell reverts to its previous value; B4_1_INDEPENDENT_REVIEW_BRIEF.md adopts that source hash and section. The manager identified this after the prepared delta was written and ordered a hold. The prepared delta is preserved, not accepted or verified. Root must record prospective disposition before further implementation/verification. This is an actual adopted contract conflict, not merely an old assertion. No design source has been edited.

## Verification plan after disposition and lane grant

Run the focused maintained table tests against original product bytes in an isolated temporary source copy to demonstrate retention failures, then against the prepared candidate; retain raw commands/output and hashes. Check TypeScript using the registered project command if granted. Parent must bind real native 100 rejection, unchanged model/history, Cancel and corrected retry to the resulting integrated candidate. Fresh independent review must cover the frozen final diff. Until then all test outcomes and native repair claims remain unavailable.
