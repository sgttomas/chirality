from pathlib import Path
import json,hashlib,sys,subprocess
R=Path.cwd();I=R/'execution/_Coordination/AgentRuns/ROOT_RUNTIME_MIGRATION_GATE5_2026-09-06/INTEGRATION';E=I/'SOURCE_CONFIG_APPLY'
if sys.argv[1:]!=['--parent-cutover-released']:raise SystemExit('Explicit parent cutover release required')
def sha(b):return hashlib.sha256(b).hexdigest()
w=[]
for r in json.loads((I/'SOURCE_WRITE_SUBJECT.json').read_text())['writes']:
 if r['kind']=='status':continue
 p=R/r['target'];before=p.read_bytes();after=(R/r['postimage']).read_bytes()
 assert sha(before)==r['before_sha256'] and sha(after)==r['after_sha256'];w.append((p,before,after))
subject=json.loads((I/'APPLICATION_SUBJECT.json').read_text());pins={r['path']:r['sha256'] for r in subject['tested_files']}
for candidate in sorted((I/'CONFIG_CANDIDATES').glob('*.yaml')):
 p=R/'execution/_harness'/candidate.name;assert p.read_bytes()==subprocess.check_output(['git','show','8209bc54e0d133b19437c93b184cd50ba3d43489:'+str(p.relative_to(R))]);after=candidate.read_bytes();assert sha(after)==pins[str(p.relative_to(R))];w.append((p,p.read_bytes(),after))
assert len(w)==11
E.mkdir();rows=[]
for p,before,after in w:
 path=str(p.relative_to(R));backup=E/'PREIMAGES'/path;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(before);rows.append({'path':path,'before_sha256':sha(before),'after_sha256':sha(after),'backup':str(backup.relative_to(R))})
def journal(state): (E/'journal.json').write_text(json.dumps({'schema':'root-source-config-application/v1','state':state,'gate5_effect':'PENDING','writes':rows},indent=2)+'\n')
journal('PREPARED');done=[]
try:
 for p,before,after in w:
  assert p.read_bytes()==before;p.write_bytes(after);done.append((p,before,after))
 assert all(p.read_bytes()==after for p,before,after in w);journal('APPLIED_PENDING_RETIREMENT');print('Applied exactly seven source and four configuration postimages; status applicator still required.')
except BaseException:
 blocked=[]
 for p,before,after in reversed(done):
  if p.read_bytes()==after:p.write_bytes(before)
  else:blocked.append(str(p))
 journal('BLOCKED_PARTIAL' if blocked else 'ROLLED_BACK');raise
