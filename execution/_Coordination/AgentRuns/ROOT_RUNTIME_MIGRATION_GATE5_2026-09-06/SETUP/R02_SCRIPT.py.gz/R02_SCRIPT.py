from pathlib import Path
import sys,shutil,json,copy,csv
root=Path.cwd();sys.path.insert(0,str(root/'tools/practitioner_harness'))
import adapter_loader,yaml
from harness_common import HarnessOperationalError
scratch=Path('/private/tmp/root-runtime-migration-20260905/gate5-adapter/chirality-runtime');scratch.mkdir(parents=True,exist_ok=True)
for r in csv.DictReader((root/'execution/_ScopeChange/SCA-005_2026-09-06_GATE4_PLAN/RUNTIME_METADATA_BINDINGS.csv').open()):
 src=root/r['Folder']/'_STATUS.md';dst=scratch/src.relative_to(root/'projects/chirality-runtime');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
data={'schema':'practitioner-harness-adapter/v1','project':'chirality-runtime','plan':'docs/PRD.md','coordination':'execution/_Coordination/_COORDINATION.md','decision_register':'execution/_Coordination/MIGRATION_APPLICATION.md','dag_pointer':'','status_glob':'execution/PKG-*/1_Working/*/_STATUS.md','exclude_globs':[],'states':['OPEN','INITIALIZED','SEMANTIC_READY','IN_PROGRESS','CHECKING','ISSUED'],'parser_dialect':'prose-bullet-v1','drift_baseline_mismatch':0,'drift_baseline_files':7,'validation_commands':[]}
p=scratch/'_harness/adapter.yaml';p.parent.mkdir(exist_ok=True);p.write_text(yaml.safe_dump(data));m=adapter_loader.load_adapter(scratch);assert m.kind=='project' and m.drift_baseline_files==7
assert len(list(scratch.glob(m.status_glob)))==7
results=[]
for label,change in [('root-schema',{'schema':'root-harness-adapter/v1'}),('root-mode',{'mode':'governance'}),('retired-state',{'states':['RETIRED']})]:
 d=copy.deepcopy(data);d.update(change);p.write_text(yaml.safe_dump(d))
 try:adapter_loader.load_adapter(scratch);raise AssertionError('accepted '+label)
 except HarnessOperationalError as e:results.append({'case':label,'rejected':True,'reason':str(e)})
p.write_text(yaml.safe_dump(data))
print(json.dumps({'R02':'PASS_ISOLATED_ORDINARY_ADAPTER_FIXTURE','carrier_count':7,'negative_cases':results,'limits':'No live adapter or runtime registration added; fixture acceptance does not approve evidence, maturity or release.'},indent=2))
