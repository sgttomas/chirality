import {ProjectRegistry} from '/Users/ryan/.codex/worktrees/341e/chirality/projects/chirality-runtime/packages/core/dist/project-registry.js';
import {mkdir,readFile,writeFile,realpath} from 'node:fs/promises';
import path from 'node:path';
const repo='/Users/ryan/.codex/worktrees/341e/chirality';
const scratch='/private/tmp/root-runtime-migration-20260905/gate5-registry';
await mkdir(scratch,{recursive:true});
const registry=new ProjectRegistry(path.join(scratch,'isolated-registry'));
const approval={approvedBy:'isolated fixture only',approvedAt:new Date().toISOString(),reason:'No operational registration; Gate4 R01 fixture'};
const manifest=path.join(repo,'projects/chirality-runtime/chirality.project.json');
const entry=await registry.register(manifest,approval,'fixture-client');
const roots=await registry.roots('chirality-runtime');
if(roots.workingRoot!==await realpath(path.dirname(manifest))||roots.instructionRoot!==await realpath(repo))throw Error('wrong roots');
const fixture=path.join(scratch,'tree/projects/chirality-runtime');await mkdir(path.join(fixture,'execution'),{recursive:true});await writeFile(path.join(fixture,'AGENTS.md'),'fixture');
const base=JSON.parse(await readFile(manifest,'utf8'));base.profiles.domain=['docs/PRD.md','execution/_Decomposition/Chirality_Runtime_SOFTWARE_DECOMP_v1_0.md'];
await mkdir(path.join(fixture,'docs'),{recursive:true});await mkdir(path.join(fixture,'execution/_Decomposition'),{recursive:true});
for(const rel of base.profiles.domain)await writeFile(path.join(fixture,rel),await readFile(path.join(repo,'projects/chirality-runtime',rel)));
const f=path.join(fixture,'chirality.project.json');await writeFile(f,JSON.stringify(base));await registry.register(f,approval,'fixture-reference-client');
await writeFile(path.join(scratch,'outside.md'),'outside declared roots');
const results=[];
for(const [label,change] of [['missing-charter',m=>m.profiles.domain=['docs/MISSING.md']],['missing-decomposition',m=>m.profiles.domain=['execution/_Decomposition/MISSING.md']],['wrong-project-identity',m=>m.projectId='../escape'],['outside-authority-path',m=>m.profiles.domain=['../../../outside.md']]]){
 const m=structuredClone(base);change(m);await writeFile(f,JSON.stringify(m));try{await registry.register(f,approval,'negative-fixture');throw Error('unexpected acceptance '+label)}catch(e){if(String(e).includes('unexpected acceptance'))throw e;results.push({label,rejected:true,reason:String(e)})}
}
console.log(JSON.stringify({R01:'PASS_ISOLATED_FIXTURE',roots,liveManifestReadOnly:manifest,registryWriteRoot:scratch,negatives:results,limits:'Syntactically safe different project names are permitted by generic registry; approved identity equality is separately checked against the approved manifest. Registry existence validation does not itself establish authority acceptance.'},null,2));
